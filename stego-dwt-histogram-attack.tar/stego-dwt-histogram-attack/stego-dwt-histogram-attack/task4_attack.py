import pywt
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import io, os

os.makedirs('results', exist_ok=True)

ALPHA     = 0.15
QUALITIES = [75, 50, 25]

def get_lh(img):
    if isinstance(img, str):
        img = Image.open(img).convert('L')
    arr = np.array(img, dtype=np.float64)
    _, (LH, _, _) = pywt.dwt2(arr, 'haar')
    return LH

def ws_score(LH):
    return float(np.mean(np.abs(LH - np.roll(LH, 1, axis=1))))

def psnr(a, b):
    mse = np.mean((a.astype(float) - b.astype(float))**2)
    return float(10 * np.log10(255**2 / mse)) if mse > 0 else float('inf')

def compute_ber(lh_attacked, lh_clean):
    wm_orig = Image.open('watermark.png').convert('L')
    wm_orig = wm_orig.resize((lh_clean.shape[1], lh_clean.shape[0]), Image.LANCZOS)
    wm_bin  = (np.array(wm_orig) > 128).astype(float)
    mx = np.abs(lh_clean).max()
    if mx == 0:
        return 0.5
    diff      = lh_attacked - lh_clean
    recovered = (diff / (ALPHA * mx)) > 0.5
    return float(np.mean(np.abs(recovered.astype(float) - wm_bin)))

img_clean = Image.open('input_image.png').convert('L')
img_stego = Image.open('stego_image.png').convert('L')
arr_clean = np.array(img_clean, dtype=np.float64)
arr_stego = np.array(img_stego, dtype=np.float64)
lh_clean  = get_lh(img_clean)
lh_stego  = get_lh(img_stego)
ws_clean  = ws_score(lh_clean)
ws_stego  = ws_score(lh_stego)

print()
print("=" * 68)
print("  KET QUA TASK 4: JPEG COMPRESSION ATTACK")
print("=" * 68)
print(f"  Baseline WS - Anh sach  : {ws_clean:.6f}")
print(f"  Baseline WS - Anh stego : {ws_stego:.6f}")
print(f"  Chenh lech ban dau      : {abs(ws_stego - ws_clean):.6f}")
print()
print(f"  {'Quality':>9} {'PSNR(dB)':>10} {'WS score':>12} {'Delta WS':>10} {'BER':>8} {'Detected?':>11}")
print(f"  {'-'*64}")

results = []
for q in QUALITIES:
    buf = io.BytesIO()
    img_stego.save(buf, format='JPEG', quality=q)
    buf.seek(0)
    img_att = Image.open(buf).convert('L')
    arr_att = np.array(img_att, dtype=np.float64)
    if arr_att.shape != arr_stego.shape:
        img_att = img_att.resize((img_stego.width, img_stego.height), Image.LANCZOS)
        arr_att = np.array(img_att, dtype=np.float64)
    lh_att   = get_lh(img_att)
    ws_att   = ws_score(lh_att)
    delta_ws = abs(ws_att - ws_clean)
    ber      = compute_ber(lh_att, lh_clean)
    psnr_val = psnr(arr_stego, arr_att)
    detected = "YES" if delta_ws > 0.05 else "NO"
    results.append({'q': q, 'psnr': psnr_val, 'ws': ws_att,
                    'delta': delta_ws, 'ber': ber, 'detected': detected, 'lh': lh_att})
    img_att.save(f'results/stego_jpeg_q{q}.png')
    print(f"  JPEG q={q:3d}  {psnr_val:>10.2f} {ws_att:>12.6f} {delta_ws:>10.6f} {ber:>8.4f} {detected:>11}")

fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle('JPEG Attack: Tac dong len Watermark va Phat hien', fontsize=13, fontweight='bold')

qs      = [r['q']     for r in results]
xlabels = [f"q={q}"   for q in qs]

axes[0].plot(xlabels, [r['ws'] for r in results], 'o-', color='tomato', linewidth=2, markersize=8)
axes[0].axhline(ws_clean, color='steelblue', linestyle='--', label=f'WS clean={ws_clean:.4f}')
axes[0].axhline(ws_stego, color='orange',    linestyle='--', label=f'WS stego={ws_stego:.4f}')
axes[0].set_title('WS Score sau JPEG Attack')
axes[0].set_ylabel('WS Score')
axes[0].legend(fontsize=8)
axes[0].invert_xaxis()

axes[1].plot(xlabels, [r['ber'] for r in results], 's-', color='purple', linewidth=2, markersize=8)
axes[1].axhline(0.5, color='red',   linestyle='--', label='BER=0.5 (mat watermark)')
axes[1].axhline(0.0, color='green', linestyle='--', label='BER=0.0 (hoan hao)')
axes[1].set_title('Bit Error Rate (BER) Watermark')
axes[1].set_ylabel('BER')
axes[1].set_ylim(-0.05, 0.6)
axes[1].legend(fontsize=8)
axes[1].invert_xaxis()

colors = ['tomato' if r['detected']=='YES' else 'steelblue' for r in results]
axes[2].bar(xlabels, [r['delta'] for r in results], color=colors, alpha=0.8)
axes[2].axhline(0.05, color='red', linestyle='--', label='Nguong 0.05')
axes[2].set_title('Delta WS Score (Do Phat hien)')
axes[2].set_ylabel('|WS_attacked - WS_clean|')
legend_els = [Patch(color='tomato',    label='Phat hien duoc (YES)'),
              Patch(color='steelblue', label='Khong phat hien (NO)')]
axes[2].legend(handles=legend_els, fontsize=8)
axes[2].invert_xaxis()

plt.tight_layout()
plt.savefig('results/attack_analysis.png', dpi=120)

fig2, axes2 = plt.subplots(1, 3, figsize=(16, 4))
fig2.suptitle('Histogram LH sau JPEG Attack', fontsize=12, fontweight='bold')
for i, r in enumerate(results):
    axes2[i].hist(r['lh'].flatten(), bins=200, density=True, color='tomato', alpha=0.7, label=f"JPEG q={r['q']}")
    axes2[i].hist(lh_clean.flatten(), bins=200, density=True, color='steelblue', alpha=0.5, label='Sach')
    axes2[i].set_title(f"JPEG q={r['q']} | BER={r['ber']:.3f} | Det={r['detected']}")
    axes2[i].set_xlabel('Gia tri he so LH')
    axes2[i].legend(fontsize=7)
plt.tight_layout()
plt.savefig('results/histogram_after_attack.png', dpi=120)

print()
print("  Da luu: results/attack_analysis.png")
print("  Da luu: results/histogram_after_attack.png")
print("=" * 68)
