import pywt
import numpy as np
from PIL import Image
import os, logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - INFO - %(message)s')

INPUT  = 'input_image.png'
WM     = 'watermark.png'
OUTPUT = 'stego_image.png'
ALPHA  = 0.15

os.makedirs('results', exist_ok=True)

img = Image.open(INPUT).convert('L')
arr = np.array(img, dtype=np.float64)
logging.info(f"Anh goc: {arr.shape}, dtype=float64")

coeffs = pywt.dwt2(arr, 'haar')
LL, (LH, HL, HH) = coeffs
logging.info(f"Kich thuoc bang LH: {LH.shape}")
logging.info(f"Max |LH|: {np.abs(LH).max():.4f}")

wm = Image.open(WM).convert('L').resize((LH.shape[1], LH.shape[0]), Image.LANCZOS)
wm_arr = np.array(wm, dtype=np.float64)
wm_bin = (wm_arr > 128).astype(np.float64)
logging.info(f"Ti le bit 1 trong watermark: {wm_bin.mean()*100:.1f}%")

LH_new = LH + ALPHA * wm_bin * np.abs(LH).max()
HL_new = HL + ALPHA * wm_bin * np.abs(HL).max()
logging.info(f"Da nhung watermark: alpha={ALPHA}")

arr_stego = pywt.idwt2((LL, (LH_new, HL_new, HH)), 'haar')
arr_stego = np.clip(arr_stego, 0, 255).astype(np.uint8)
Image.fromarray(arr_stego).save(OUTPUT)

mse  = np.mean((arr - arr_stego.astype(np.float64))**2)
psnr = 10 * np.log10(255**2 / mse) if mse > 0 else float('inf')

print()
print("=" * 58)
print("  KET QUA TASK 1: NHUNG WATERMARK")
print("=" * 58)
print(f"  Anh goc   : {INPUT}  ({arr.shape})")
print(f"  Anh stego : {OUTPUT} ({arr_stego.shape})")
print(f"  Alpha     : {ALPHA}")
print(f"  PSNR      : {psnr:.4f} dB")
print(f"  MSE       : {mse:.4f}")
print()
if psnr >= 35:
    print("  [OK] PSNR >= 35dB: Watermark vo hinh tot")
elif psnr >= 30:
    print("  [OK] PSNR >= 30dB: Chat luong chap nhan duoc")
else:
    print("  [!] PSNR < 30dB : Watermark co the nhin thay")
print("=" * 58)
