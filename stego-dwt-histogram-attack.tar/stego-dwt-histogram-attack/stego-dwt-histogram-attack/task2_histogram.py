import pywt
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import os

os.makedirs('results', exist_ok=True)

def get_lh(path):
    img = Image.open(path).convert('L')
    arr = np.array(img, dtype=np.float64)
    _, (LH, _, _) = pywt.dwt2(arr, 'haar')
    return LH.flatten()

def skewness(x):
    return float(((x - x.mean())**3).mean() / x.std()**3)

def kurtosis(x):
    return float(((x - x.mean())**4).mean() / x.std()**4)

lh_clean = get_lh('input_image.png')
lh_stego = get_lh('stego_image.png')

print()
print("=" * 62)
print("  KET QUA TASK 2: PHAN TICH HISTOGRAM HE SO LH")
print("=" * 62)
print(f"  {'Chi so':<18} {'Anh sach':>14} {'Anh stego':>14} {'Chenh lech':>12}")
print(f"  {'-'*58}")

stats = {}
for name, data in [('clean', lh_clean), ('stego', lh_stego)]:
    stats[name] = {
        'mean': data.mean(), 'std': data.std(),
        'skew': skewness(data), 'kurt': kurtosis(data),
        'min': data.min(), 'max': data.max(),
    }

rows = [
    ('Mean',     'mean', '{:>14.6f}'),
    ('Std',      'std',  '{:>14.6f}'),
    ('Skewness', 'skew', '{:>14.6f}'),
    ('Kurtosis', 'kurt', '{:>14.6f}'),
    ('Min',      'min',  '{:>14.4f}'),
    ('Max',      'max',  '{:>14.4f}'),
]
for label, key, fmt in rows:
    c = stats['clean'][key]
    s = stats['stego'][key]
    d = s - c
    print(f"  {label:<18}" + fmt.format(c) + fmt.format(s) + fmt.format(d))

fig, axes = plt.subplots(2, 2, figsize=(14, 10))
fig.suptitle('Phan tich Histogram He so DWT - Bang LH', fontsize=14, fontweight='bold')

axes[0,0].hist(lh_clean, bins=200, color='steelblue', alpha=0.85, density=True)
axes[0,0].set_title('Histogram LH - Anh sach', fontweight='bold')
axes[0,0].set_xlabel('Gia tri he so LH')
axes[0,0].set_ylabel('Mat do xac suat')
axes[0,0].axvline(lh_clean.mean(), color='red', linestyle='--', linewidth=1.5,
                  label=f"Mean={lh_clean.mean():.3f}")
axes[0,0].legend()

axes[0,1].hist(lh_stego, bins=200, color='tomato', alpha=0.85, density=True)
axes[0,1].set_title('Histogram LH - Anh stego', fontweight='bold')
axes[0,1].set_xlabel('Gia tri he so LH')
axes[0,1].set_ylabel('Mat do xac suat')
axes[0,1].axvline(lh_stego.mean(), color='darkred', linestyle='--', linewidth=1.5,
                  label=f"Mean={lh_stego.mean():.3f}")
axes[0,1].legend()

axes[1,0].hist(lh_clean, bins=200, color='steelblue', alpha=0.55, density=True, label='Sach')
axes[1,0].hist(lh_stego, bins=200, color='tomato', alpha=0.55, density=True, label='Stego')
axes[1,0].set_title('Chong Histogram: Sach vs Stego', fontweight='bold')
axes[1,0].set_xlabel('Gia tri he so LH')
axes[1,0].legend()

hist_c, edges = np.histogram(lh_clean, bins=200, density=True)
hist_s, _     = np.histogram(lh_stego, bins=edges, density=True)
centers       = (edges[:-1] + edges[1:]) / 2
diff          = hist_s - hist_c
axes[1,1].bar(centers, diff, width=np.diff(edges),
              color=np.where(diff >= 0, 'tomato', 'steelblue'), alpha=0.8)
axes[1,1].axhline(0, color='black', linewidth=1)
axes[1,1].set_title('Difference Plot: Stego - Sach', fontweight='bold')
axes[1,1].set_xlabel('Gia tri he so LH')
axes[1,1].set_ylabel('Chenh lech mat do')

plt.tight_layout()
out = 'results/histogram_comparison.png'
plt.savefig(out, dpi=120)
print()
print(f"  Da luu bieu do: {out}")
print(f"  Mo xem        : eog {out}")
print("=" * 62)
