import pywt
import numpy as np
from PIL import Image
from scipy import stats as scipy_stats

def load_lh(path):
    img = Image.open(path).convert('L')
    arr = np.array(img, dtype=np.float64)
    _, (LH, _, _) = pywt.dwt2(arr, 'haar')
    return LH

def ws_score(LH):
    shifted = np.roll(LH, 1, axis=1)
    return float(np.mean(np.abs(LH - shifted)))

def chi_square_test(LH, bins=60):
    flat = LH.flatten()
    observed, edges = np.histogram(flat, bins=bins)
    loc, scale      = scipy_stats.laplace.fit(flat)
    expected        = (np.diff(scipy_stats.laplace.cdf(edges, loc, scale)) * len(flat))
    mask    = expected > 1.0
    chi2    = float(np.sum((observed[mask] - expected[mask])**2 / expected[mask]))
    df      = mask.sum() - 3
    pvalue  = float(1 - scipy_stats.chi2.cdf(chi2, df))
    return chi2, pvalue, loc, scale

lh_clean = load_lh('input_image.png')
lh_stego = load_lh('stego_image.png')

ws_c = ws_score(lh_clean)
ws_s = ws_score(lh_stego)
diff = abs(ws_s - ws_c)

chi2_c, p_c, loc_c, scale_c = chi_square_test(lh_clean)
chi2_s, p_s, loc_s, scale_s = chi_square_test(lh_stego)

print()
print("=" * 62)
print("  KET QUA TASK 3: PHAT HIEN THONG KE")
print("=" * 62)
print()
print("  [A] WS DETECTOR")
print(f"      WS score anh sach  : {ws_c:.6f}")
print(f"      WS score anh stego : {ws_s:.6f}")
print(f"      Chenh lech         : {diff:.6f}")
print(f"      Nguong phat hien   : 0.05")
verdict_ws = "DETECTED" if diff > 0.05 else "NOT DETECTED"
print(f"  => WS Detector: [{verdict_ws}]")
print()
print("  [B] CHI-SQUARE TEST  (H0: phan phoi Laplace tu nhien)")
print(f"  {'':3} {'':22} {'Chi2':>12} {'p-value':>12} {'Ket luan':>14}")
print(f"  {'':3} {'-'*58}")
for label, chi2, pv in [('Anh sach', chi2_c, p_c), ('Anh stego', chi2_s, p_s)]:
    verdict = "bat thuong" if pv < 0.05 else "binh thuong"
    print(f"  {'':3} {label:<22} {chi2:>12.4f} {pv:>12.6f} {verdict:>14}")
print()
print(f"  Tham so Laplace fit anh sach : loc={loc_c:.4f}, scale={scale_c:.4f}")
print(f"  Tham so Laplace fit anh stego: loc={loc_s:.4f}, scale={scale_s:.4f}")
print("=" * 62)
