import numpy as np
import json, math

IA = np.load('results/IA.npy')
SA = np.load('results/SA.npy')

BLOCK_SIZE = 2


def split_blocks(matrix, block_size):
    blocks, coords = [], []
    h, w = matrix.shape
    for r in range(0, h - block_size + 1, block_size):
        for c in range(0, w - block_size + 1, block_size):
            blocks.append(matrix[r:r+block_size, c:c+block_size])
            coords.append((r, c))
    return blocks, coords


def rmse(block_a, block_b):
    diff_sq = (block_a.astype(float) - block_b.astype(float)) ** 2
    return math.sqrt(diff_sq.mean())


BIA_list, BIA_coords = split_blocks(IA, BLOCK_SIZE)
BSA_list, _          = split_blocks(SA, BLOCK_SIZE)

print("=" * 65)
print("  [TASK 2] CHIA KHOI VA RMSE MATCHING")
print("=" * 65)
print("  Dai IA (LL)  : {}x{} px -> {} khoi {}x{}".format(
    IA.shape[1], IA.shape[0], len(BIA_list), BLOCK_SIZE, BLOCK_SIZE))
print("  Ma tran SA   : {}x{} px -> {} khoi {}x{}".format(
    SA.shape[1], SA.shape[0], len(BSA_list), BLOCK_SIZE, BLOCK_SIZE))
print()

K1 = []

print("  RMSE MATCHING (tim khoi BIA gan BSA nhat):")
print("  {:>6} {:>12} {:>12} {:>12}".format(
    'BSA_i', 'RMSE_min', 'K1[i]', 'Gia tri RMSE'))
print("  " + "-" * 48)

for i, bsa in enumerate(BSA_list):
    rmse_vals = [rmse(bsa, bia) for bia in BIA_list]
    best_j    = int(np.argmin(rmse_vals))
    best_rmse = rmse_vals[best_j]
    K1.append(best_j)
    if i < 6:
        print("  {:>6} {:>12.4f} {:>12} {:>12.4f}".format(
            i, best_rmse, best_j, best_rmse))

if len(BSA_list) > 6:
    print("  ... ({} khoi con lai)".format(len(BSA_list) - 6))

print()
print("  K1 = {}".format(K1))

np.save('results/BIA_list.npy',   np.array([b.flatten() for b in BIA_list]))
np.save('results/BSA_list.npy',   np.array([b.flatten() for b in BSA_list]))
np.save('results/BIA_coords.npy', np.array(BIA_coords))
with open('results/K1.json', 'w') as f:
    json.dump({'K1': K1, 'block_size': BLOCK_SIZE,
               'n_BIA': len(BIA_list), 'n_BSA': len(BSA_list)}, f, indent=2)

print("  Da luu: results/K1.json")
print("=" * 65)
