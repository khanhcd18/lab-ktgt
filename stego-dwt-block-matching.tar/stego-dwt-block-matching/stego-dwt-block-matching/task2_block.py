import numpy as np
import json, math

# Doc ket qua tu task 1
IA = np.load('results/IA.npy')   # Dai LL cua anh chua
SA = np.load('results/SA.npy')   # Ma tran ASCII cua tin bi mat

BLOCK_SIZE = 2   # Kich thuoc khoi: 2x2 pixel

# ================================================================
# Ham chia ma tran thanh cac khoi BLOCK_SIZE x BLOCK_SIZE
# ================================================================
def split_blocks(matrix, block_size):
    """
    Chia ma tran thanh cac khoi vuong khong chong nhau.
    Moi khoi co kich thuoc block_size x block_size.
    Tra ve list cac khoi va list toa do goc trai tren cua moi khoi.
    """
    blocks = []
    coords = []
    h, w   = matrix.shape
    for r in range(0, h - block_size + 1, block_size):
        for c in range(0, w - block_size + 1, block_size):
            blocks.append(matrix[r:r+block_size, c:c+block_size])
            coords.append((r, c))
    return blocks, coords

    # [CODE MAU - bo dau # de chay]
    # blocks = []
    # coords = []
    # h, w = matrix.shape
    # for r in range(0, h - block_size + 1, block_size):
    #     for c in range(0, w - block_size + 1, block_size):
    #         blocks.append(matrix[r:r+block_size, c:c+block_size])
    #         coords.append((r, c))
    # return blocks, coords


# ================================================================
# Ham tinh RMSE giua 2 khoi
# RMSE = can bac hai cua trung binh binh phuong sai lech
# Cong thuc: RMSE = sqrt( mean( (A - B)^2 ) )
# RMSE cang nho → 2 khoi cang giong nhau
# ================================================================
def rmse(block_a, block_b):
    """
    Tinh Root Mean Square Error giua 2 khoi co cung kich thuoc.
    """
    # Tinh binh phuong sai lech tung cap phan tu
    diff_sq = (block_a.astype(float) - block_b.astype(float)) ** 2
    # Tinh trung binh cac gia tri binh phuong
    mean_sq = diff_sq.mean()
    # Lay can bac hai de co don vi goc (pixel value)
    return math.sqrt(mean_sq)

    # [CODE MAU - bo dau # de chay]
    # diff_sq = (block_a.astype(float) - block_b.astype(float)) ** 2
    # mean_sq = diff_sq.mean()
    # return math.sqrt(mean_sq)


# ================================================================
# Chia khoi
# ================================================================
BIA_list, BIA_coords = split_blocks(IA, BLOCK_SIZE)
BSA_list, _          = split_blocks(SA, BLOCK_SIZE)

print("=" * 65)
print("  [TASK 2] CHIA KHOI VA RMSE MATCHING")
print("=" * 65)
print("  Dai IA (LL)  : {}x{} px → {} khoi {}x{}".format(
    IA.shape[1], IA.shape[0], len(BIA_list), BLOCK_SIZE, BLOCK_SIZE))
print("  Ma tran SA   : {}x{} px → {} khoi {}x{}".format(
    SA.shape[1], SA.shape[0], len(BSA_list), BLOCK_SIZE, BLOCK_SIZE))
print()

# ================================================================
# RMSE Matching: Tim khoi BIA phu hop nhat voi moi khoi BSA
# Khoa K1 luu vi tri cua khoi BIA co RMSE nho nhat voi BSA
# ================================================================
K1 = []   # Khoa K1: luu chi so j cua khoi BIA phu hop nhat

print("  RMSE MATCHING (tim khoi BIA gan BSA nhat):")
print("  {:>6} {:>12} {:>12} {:>12}".format(
    'BSA_i', 'RMSE_min', 'K1[i]', 'Gia tri RMSE'))
print("  " + "-" * 48)

for i, bsa in enumerate(BSA_list):
    rmse_vals = []
    for j, bia in enumerate(BIA_list):
        rmse_vals.append(rmse(bsa, bia))

    best_j    = int(np.argmin(rmse_vals))
    best_rmse = rmse_vals[best_j]
    K1.append(best_j)

    if i < 6:   # Chi in 6 hang dau de khong qua dai
        print("  {:>6} {:>12.4f} {:>12} {:>12.4f}".format(
            i, best_rmse, best_j, best_rmse))

if len(BSA_list) > 6:
    print("  ... ({} khoi con lai)".format(len(BSA_list) - 6))

print()
print("  K1 = {} (chi so {} khoi)".format(K1, len(K1)))

# Luu ket qua
np.save('results/BIA_list.npy', np.array([b.flatten() for b in BIA_list]))
np.save('results/BSA_list.npy', np.array([b.flatten() for b in BSA_list]))
np.save('results/BIA_coords.npy', np.array(BIA_coords))
with open('results/K1.json', 'w') as f:
    json.dump({'K1': K1, 'block_size': BLOCK_SIZE,
               'n_BIA': len(BIA_list), 'n_BSA': len(BSA_list)}, f, indent=2)

print()
print("  Da luu: results/K1.json")
print("=" * 65)
