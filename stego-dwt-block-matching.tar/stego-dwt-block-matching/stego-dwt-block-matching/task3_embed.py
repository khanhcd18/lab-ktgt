import numpy as np
import json, math

# Doc ket qua tu cac task truoc
IA  = np.load('results/IA.npy')
IH  = np.load('results/IH.npy')
IV  = np.load('results/IV.npy')
ID  = np.load('results/ID.npy')
SA  = np.load('results/SA.npy')

k1_data    = json.load(open('results/K1.json'))
K1         = k1_data['K1']
BLOCK_SIZE = k1_data['block_size']

def split_blocks(matrix, block_size):
    blocks, coords = [], []
    h, w = matrix.shape
    for r in range(0, h - block_size + 1, block_size):
        for c in range(0, w - block_size + 1, block_size):
            blocks.append(matrix[r:r+block_size, c:c+block_size].copy())
            coords.append((r, c))
    return blocks, coords

def rmse(a, b):
    return math.sqrt(((a.astype(float) - b.astype(float))**2).mean())

BIA_list, BIA_coords = split_blocks(IA, BLOCK_SIZE)
BSA_list, _          = split_blocks(SA, BLOCK_SIZE)
BIH_list, BIH_coords = split_blocks(IH, BLOCK_SIZE)
BIV_list, BIV_coords = split_blocks(IV, BLOCK_SIZE)
BID_list, BID_coords = split_blocks(ID, BLOCK_SIZE)

# ================================================================
# BUOC 1: Tinh khoi chenh lech DB
# DB = BSA - BIA(phu hop nhat)
# DB the hien su khac biet giua tin bi mat va vung anh tuong ung
# Gia tri nay se duoc nhung vao cac dai IH, IV, ID
# ================================================================
def compute_db(bsa, bia_best):
    """
    Tinh khoi chenh lech giua khoi tin bi mat va khoi anh phu hop nhat.
    Cong thuc: DB = BSA - BIA_best
    """
    # Lay gia tri float cua 2 khoi de tranh tran so nguyen
    # Phep tru tra ve ma tran chenh lech
    return bsa.astype(float) - bia_best.astype(float)

    # [CODE MAU - bo dau # de chay]
    # return bsa.astype(float) - bia_best.astype(float)


# ================================================================
# BUOC 2: Tim khoi phu hop nhat trong IH, IV, ID cho moi DB
# Su dung RMSE de chon dai co khoi gan DB nhat
# Khoa K2, K3, K4 luu vi tri khoi trong IH, IV, ID tuong ung
# ================================================================
def find_best_band(db, band_blocks):
    """
    Tim khoi co RMSE nho nhat voi khoi chenh lech DB
    trong danh sach cac khoi cua mot dai tan so.
    Tra ve: (chi_so_khoi_tot_nhat, gia_tri_rmse_nho_nhat)
    """
    best_idx  = 0
    best_rmse = float('inf')
    for idx, blk in enumerate(band_blocks):
        r = rmse(db, blk)
        if r < best_rmse:
            best_rmse = r
            best_idx  = idx
    return best_idx, best_rmse

    # [CODE MAU - bo dau # de chay]
    # best_idx  = 0
    # best_rmse = float('inf')
    # for idx, blk in enumerate(band_blocks):
    #     r = rmse(db, blk)
    #     if r < best_rmse:
    #         best_rmse = r
    #         best_idx  = idx
    # return best_idx, best_rmse


print("=" * 68)
print("  [TASK 3] TINH DB VA THAY THE KHOI")
print("=" * 68)
print()
print("  {:>5} {:>12} {:>12} {:>12} {:>12} {:>8}".format(
    'BSA_i', 'RMSE_IH', 'RMSE_IV', 'RMSE_ID', 'Chon dai', 'K'))
print("  " + "-" * 62)

K2, K3, K4 = [], [], []
IH_new = IH.copy()
IV_new = IV.copy()
ID_new = ID.copy()

for i, (bsa, k1_idx) in enumerate(zip(BSA_list, K1)):
    bia_best = BIA_list[k1_idx]

    # Tinh khoi chenh lech
    db = compute_db(bsa, bia_best)

    # Tim khoi phu hop trong IH, IV, ID
    j_IH, r_IH = find_best_band(db, BIH_list)
    j_IV, r_IV = find_best_band(db, BIV_list)
    j_ID, r_ID = find_best_band(db, BID_list)

    # Chon dai co RMSE nho nhat de thay the
    # Thay the DB vao khoi phu hop nhat cua dai duoc chon
    min_rmse = min(r_IH, r_IV, r_ID)
    if min_rmse == r_IH:
        chosen = 'IH'
        r, c   = BIH_coords[j_IH]
        IH_new[r:r+BLOCK_SIZE, c:c+BLOCK_SIZE] = db
        K2.append(j_IH); K3.append(-1); K4.append(-1)
    elif min_rmse == r_IV:
        chosen = 'IV'
        r, c   = BIV_coords[j_IV]
        IV_new[r:r+BLOCK_SIZE, c:c+BLOCK_SIZE] = db
        K2.append(-1); K3.append(j_IV); K4.append(-1)
    else:
        chosen = 'ID'
        r, c   = BID_coords[j_ID]
        ID_new[r:r+BLOCK_SIZE, c:c+BLOCK_SIZE] = db
        K2.append(-1); K3.append(-1); K4.append(j_ID)

    if i < 6:
        print("  {:>5} {:>12.4f} {:>12.4f} {:>12.4f} {:>12} {:>8}".format(
            i, r_IH, r_IV, r_ID, chosen,
            j_IH if chosen=='IH' else j_IV if chosen=='IV' else j_ID))

if len(BSA_list) > 6:
    print("  ... ({} khoi con lai)".format(len(BSA_list) - 6))

# Luu cac dai da duoc cap nhat
np.save('results/IH_new.npy', IH_new)
np.save('results/IV_new.npy', IV_new)
np.save('results/ID_new.npy', ID_new)

with open('results/keys.json', 'w') as f:
    json.dump({'K1': K1, 'K2': K2, 'K3': K3, 'K4': K4,
               'block_size': BLOCK_SIZE,
               'IA_shape': list(IA.shape),
               'IH_shape': list(IH.shape),
               'SA_shape': list(SA.shape)}, f, indent=2)

print()
print("  K2 (IH) = {}".format([k for k in K2 if k >= 0]))
print("  K3 (IV) = {}".format([k for k in K3 if k >= 0]))
print("  K4 (ID) = {}".format([k for k in K4 if k >= 0]))
print()
print("  Da luu: results/keys.json")
print("=" * 68)
