import numpy as np
import json, math

IA = np.load('results/IA.npy')
IH = np.load('results/IH.npy')
IV = np.load('results/IV.npy')
ID = np.load('results/ID.npy')
SA = np.load('results/SA.npy')

k1_data    = json.load(open('results/K1.json'))
K1         = k1_data['K1']
BLOCK_SIZE = k1_data['block_size']


def split_blocks(matrix, block_size):
    blocks, coords = [], []
    h, w = matrix.shape
    for r in range(0, h - block_size + 1, block_size):
        for c in range(0, w - block_size + 1, block_size):
            blocks.append(matrix[r:r+block_size, c:c+block_size].copy())
            coords.append((r, c))
    return blocks, coords


def rmse(a, b):
    return math.sqrt(((a.astype(float) - b.astype(float))**2).mean())


def compute_db(bsa, bia_best):
    return bsa.astype(float) - bia_best.astype(float)


def find_best_band(db, band_blocks, used_indices):
    best_idx, best_rmse = 0, float('inf')
    for idx, blk in enumerate(band_blocks):
        if idx in used_indices:
            continue
        r = rmse(db, blk)
        if r < best_rmse:
            best_rmse = r
            best_idx  = idx
    return best_idx, best_rmse


BIA_list, BIA_coords = split_blocks(IA, BLOCK_SIZE)
BSA_list, _          = split_blocks(SA, BLOCK_SIZE)
BIH_list, BIH_coords = split_blocks(IH, BLOCK_SIZE)
BIV_list, BIV_coords = split_blocks(IV, BLOCK_SIZE)
BID_list, BID_coords = split_blocks(ID, BLOCK_SIZE)

print("=" * 68)
print("  [TASK 3] TINH DB VA THAY THE KHOI")
print("=" * 68)
print()
print("  {:>5} {:>12} {:>12} {:>12} {:>12} {:>8}".format(
    'BSA_i', 'RMSE_IH', 'RMSE_IV', 'RMSE_ID', 'Chon dai', 'K'))
print("  " + "-" * 62)

K2, K3, K4 = [], [], []
IH_new = IH.copy()
IV_new = IV.copy()
ID_new = ID.copy()
used_IH, used_IV, used_ID = set(), set(), set()

for i, (bsa, k1_idx) in enumerate(zip(BSA_list, K1)):
    db = compute_db(bsa, BIA_list[k1_idx])

    j_IH, r_IH = find_best_band(db, BIH_list, used_IH)
    j_IV, r_IV = find_best_band(db, BIV_list, used_IV)
    j_ID, r_ID = find_best_band(db, BID_list, used_ID)

    min_rmse = min(r_IH, r_IV, r_ID)
    if min_rmse == r_IH:
        chosen = 'IH'
        r, c   = BIH_coords[j_IH]
        IH_new[r:r+BLOCK_SIZE, c:c+BLOCK_SIZE] = db
        used_IH.add(j_IH)
        K2.append(j_IH); K3.append(-1); K4.append(-1)
    elif min_rmse == r_IV:
        chosen = 'IV'
        r, c   = BIV_coords[j_IV]
        IV_new[r:r+BLOCK_SIZE, c:c+BLOCK_SIZE] = db
        used_IV.add(j_IV)
        K2.append(-1); K3.append(j_IV); K4.append(-1)
    else:
        chosen = 'ID'
        r, c   = BID_coords[j_ID]
        ID_new[r:r+BLOCK_SIZE, c:c+BLOCK_SIZE] = db
        used_ID.add(j_ID)
        K2.append(-1); K3.append(-1); K4.append(j_ID)

    if i < 6:
        print("  {:>5} {:>12.4f} {:>12.4f} {:>12.4f} {:>12} {:>8}".format(
            i, r_IH, r_IV, r_ID, chosen,
            j_IH if chosen == 'IH' else j_IV if chosen == 'IV' else j_ID))

if len(BSA_list) > 6:
    print("  ... ({} khoi con lai)".format(len(BSA_list) - 6))

np.save('results/IH_new.npy', IH_new)
np.save('results/IV_new.npy', IV_new)
np.save('results/ID_new.npy', ID_new)

with open('results/keys.json', 'w') as f:
    json.dump({'K1': K1, 'K2': K2, 'K3': K3, 'K4': K4,
               'block_size': BLOCK_SIZE,
               'IA_shape':   list(IA.shape),
               'IH_shape':   list(IH.shape),
               'SA_shape':   list(SA.shape)}, f, indent=2)

print()
print("  K2 (IH) = {}".format([k for k in K2 if k >= 0]))
print("  K3 (IV) = {}".format([k for k in K3 if k >= 0]))
print("  K4 (ID) = {}".format([k for k in K4 if k >= 0]))
print()
print("  Da luu: results/keys.json")
print("=" * 68)
