import pywt
import numpy as np
from PIL import Image
import os, json

os.makedirs('results', exist_ok=True)

SECRET_TEXT = 'PTIT SECRET MESSAGE 2026'
INPUT_PATH  = 'input_image.png'

# Doc anh chua
img = Image.open(INPUT_PATH).convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape

# Chuyen text bi mat thanh ma tran ASCII (SA)
# Moi ky tu ASCII la 1 so nguyen 0-255
ascii_vals = [ord(c) for c in SECRET_TEXT]
# Dem so hang can thiet de chua du ky tu trong ma tran 4 cot
n_rows = (len(ascii_vals) + 3) // 4
# Dem so 0 can them vao cuoi de lap day ma tran 4 cot
ascii_vals += [0] * (n_rows * 4 - len(ascii_vals))
SA = np.array(ascii_vals, dtype=np.float64).reshape(n_rows, 4)

# Ap dung DWT Haar len anh chua
# Thu duoc 4 dai tan so: LL (xap xi), LH (chi tiet ngang),
#                        HL (chi tiet doc), HH (chi tiet cheo)
coeffs = pywt.dwt2(arr, 'haar')
LL, (LH, HL, HH) = coeffs

# Luu cac ket qua trung gian de cac task sau su dung
np.save('results/IA.npy', LL)
np.save('results/IH.npy', LH)
np.save('results/IV.npy', HL)
np.save('results/ID.npy', HH)
np.save('results/SA.npy', SA)

with open('results/config.json', 'w') as f:
    json.dump({'secret_text': SECRET_TEXT,
               'image_shape': [H, W],
               'SA_shape': list(SA.shape)}, f, indent=2)

# Visualize 4 dai tan so
def normalize(band):
    b = band.copy()
    mn, mx = b.min(), b.max()
    if mx == mn:
        return np.zeros_like(b, dtype=np.uint8)
    return ((b - mn) / (mx - mn) * 255).astype(np.uint8)

h2, w2 = LL.shape
gap = 4
canvas = np.ones((h2*2+gap*3, w2*2+gap*3), dtype=np.uint8) * 180
canvas[gap:gap+h2,           gap:gap+w2]           = normalize(LL)
canvas[gap:gap+h2,           gap+w2+gap:gap+w2*2+gap] = normalize(LH)
canvas[gap+h2+gap:gap+h2*2+gap, gap:gap+w2]           = normalize(HL)
canvas[gap+h2+gap:gap+h2*2+gap, gap+w2+gap:gap+w2*2+gap] = normalize(HH)
Image.fromarray(canvas).save('results/dwt_subbands.png')

total_energy = np.sum(LL**2) + np.sum(LH**2) + np.sum(HL**2) + np.sum(HH**2)

print("=" * 60)
print("  [TASK 1] BIEN DOI DWT VA CHUAN BI DU LIEU")
print("=" * 60)
print("  Anh chua       : {}x{} px  |  Haar DWT".format(W, H))
print("  Kich thuoc dai : {}x{} px moi dai".format(w2, h2))
print()
print("  PHAN PHOI NANG LUONG:")
for name, band in [('LL (xap xi)', LL), ('LH (ngang)', LH),
                   ('HL (doc)  ', HL), ('HH (cheo) ', HH)]:
    e = np.sum(band**2)
    print("    Dai {} : {:>12.0f}  ({:.2f}%)".format(
        name, e, 100*e/total_energy))
print()
print("  TIN BI MAT:")
print("    Noi dung : '{}'".format(SECRET_TEXT))
print("    Do dai   : {} ky tu".format(len(SECRET_TEXT)))
print("    Ma tran SA: {}x4 (gia tri ASCII)".format(n_rows))
print()
print("    SA =")
for row in SA:
    print("      {}".format([int(v) for v in row]))
print()
print("  Da luu: results/dwt_subbands.png")
print("  Mo xem: eog results/dwt_subbands.png")
print("=" * 60)
