import pywt
import numpy as np
from PIL import Image
import json, math

IA     = np.load('results/IA.npy')
IH_new = np.load('results/IH_new.npy')
IV_new = np.load('results/IV_new.npy')
ID_new = np.load('results/ID_new.npy')

config = json.load(open('results/config.json'))
H, W   = config['image_shape']


def idwt_reconstruct(LL, LH, HL, HH):
    coeffs_new = (LL, (LH, HL, HH))
    img_rec    = pywt.idwt2(coeffs_new, 'haar')
    return np.clip(img_rec, 0, 255).astype(np.uint8)


def compute_psnr(original, stego):
    mse = np.mean((original.astype(float) - stego.astype(float))**2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(255.0 / math.sqrt(mse))


stego_arr = idwt_reconstruct(IA, IH_new, IV_new, ID_new)[:H, :W]

img_orig = Image.open('input_image.png').convert('L')
orig_arr = np.array(img_orig, dtype=np.uint8)

psnr    = compute_psnr(orig_arr, stego_arr)
mse_val = np.mean((orig_arr.astype(float) - stego_arr.astype(float))**2)
max_diff = int(np.abs(orig_arr.astype(int) - stego_arr.astype(int)).max())

Image.fromarray(stego_arr).save('results/stego_image.png')

gap         = 8
compare_arr = np.ones((H, W*2+gap), dtype=np.uint8) * 128
compare_arr[:, :W]     = orig_arr
compare_arr[:, W+gap:] = stego_arr
Image.fromarray(compare_arr).save('results/compare.png')

diff        = np.abs(orig_arr.astype(int) - stego_arr.astype(int))
diff_scaled = np.clip(diff * 36, 0, 255).astype(np.uint8)
Image.fromarray(diff_scaled).save('results/diff_map.png')

print("=" * 62)
print("  [TASK 4] BIEN DOI DWT NGUOC VA XUAT ANH STEGO")
print("=" * 62)
print()
print("  INPUT  : IA + IH_new + IV_new + ID_new")
print("  OUTPUT : results/stego_image.png  ({}x{})".format(W, H))
print()
print("  DANH GIA CHAT LUONG:")
print("    PSNR anh stego vs goc : {:.4f} dB  ({})".format(
    psnr, "TOT" if psnr >= 40 else "CHAP NHAN DUOC" if psnr >= 30 else "THAP"))
print("    MSE                   : {:.4f}".format(mse_val))
print("    Max diff pixel        : {}".format(max_diff))
print()
print("  File da luu:")
print("    results/stego_image.png")
print("    results/compare.png")
print("    results/diff_map.png")
print("    results/keys.json")
print()
print("  Mo xem:")
print("    eog results/stego_image.png")
print("    eog results/compare.png")
print("    eog results/diff_map.png")
print("=" * 62)
