import pywt
import numpy as np
from PIL import Image
import json, math

# Doc ket qua tu cac task truoc
IA     = np.load('results/IA.npy')
IH_new = np.load('results/IH_new.npy')
IV_new = np.load('results/IV_new.npy')
ID_new = np.load('results/ID_new.npy')

config = json.load(open('results/config.json'))
H, W   = config['image_shape']

# ================================================================
# Bien doi DWT nguoc (IDWT)
# Ghep 4 dai tan so lai thanh anh hoan chinh chua tin giau
# Thu tu: cac dai IH/IV/ID da duoc thay the DB → ghep → IDWT → anh I'
# Quy trinh nguoc voi DWT:
#   DWT : anh I → [IA, IH, IV, ID]
#   IDWT: [IA, IH_new, IV_new, ID_new] → anh I'
# ================================================================
def idwt_reconstruct(LL, LH, HL, HH):
    """
    Thuc hien bien doi DWT nguoc de thu hoi anh tu 4 dai tan so.
    Input : LL (xap xi), LH (ngang), HL (doc), HH (cheo) da duoc cap nhat
    Output: anh nguyen ven chua tin giau, gia tri pixel [0, 255]
    """
    # Ghep 4 dai vao ham IDWT Haar
    coeffs_new = (LL, (LH, HL, HH))
    # Bien doi nguoc tra ve mang float, clip ve [0,255]
    img_rec    = pywt.idwt2(coeffs_new, 'haar')
    return np.clip(img_rec, 0, 255).astype(np.uint8)

    # [CODE MAU - bo dau # de chay]
    # coeffs_new = (LL, (LH, HL, HH))
    # img_rec    = pywt.idwt2(coeffs_new, 'haar')
    # return np.clip(img_rec, 0, 255).astype(np.uint8)


# ================================================================
# Tinh PSNR de danh gia chat luong anh stego
# PSNR = 20 × log10(255 / sqrt(MSE))
# PSNR >= 30 dB: chap nhan duoc  |  >= 40 dB: tot
# ================================================================
def compute_psnr(original, stego):
    """
    Tinh Peak Signal-to-Noise Ratio giua anh goc va anh stego.
    PSNR cang cao → anh stego cang giong anh goc → watermark cang an.
    """
    # Tinh sai so binh phuong trung binh (MSE)
    mse = np.mean((original.astype(float) - stego.astype(float))**2)
    if mse == 0:
        return float('inf')
    # Ap dung cong thuc PSNR, 255 la gia tri pixel toi da
    return 20 * math.log10(255.0 / math.sqrt(mse))

    # [CODE MAU - bo dau # de chay]
    # mse = np.mean((original.astype(float) - stego.astype(float))**2)
    # if mse == 0:
    #     return float('inf')
    # return 20 * math.log10(255.0 / math.sqrt(mse))


# Thuc hien IDWT
stego_arr = idwt_reconstruct(IA, IH_new, IV_new, ID_new)

# Clip ve dung kich thuoc anh goc (IDWT doi khi tra ve lon hon 1 pixel)
stego_arr = stego_arr[:H, :W]

# Doc anh goc de tinh PSNR
img_orig = Image.open('input_image.png').convert('L')
orig_arr = np.array(img_orig, dtype=np.uint8)

psnr = compute_psnr(orig_arr, stego_arr)

# Luu anh stego va anh so sanh
Image.fromarray(stego_arr).save('results/stego_image.png')

# Tao anh so sanh ngang: anh goc | anh stego
gap         = 8
compare_arr = np.ones((H, W*2+gap), dtype=np.uint8) * 128
compare_arr[:, :W]         = orig_arr
compare_arr[:, W+gap:]     = stego_arr
Image.fromarray(compare_arr).save('results/compare.png')

# Tao ban do sai khac (phong to x10 de nhin ro)
diff        = np.abs(orig_arr.astype(int) - stego_arr.astype(int))
diff_scaled = np.clip(diff * 10, 0, 255).astype(np.uint8)
Image.fromarray(diff_scaled).save('results/diff_map.png')

print("=" * 62)
print("  [TASK 4] BIEN DOI DWT NGUOC VA XUAT ANH STEGO")
print("=" * 62)
print()
print("  INPUT  : IA + IH_new + IV_new + ID_new")
print("  OUTPUT : results/stego_image.png  ({}x{})".format(W, H))
print()
print("  DANH GIA CHAT LUONG:")
print("    PSNR anh stego vs goc : {:.4f} dB  ({})".format(
    psnr, "TOT" if psnr >= 40 else "CHAP NHAN DUOC" if psnr >= 30 else "THAP"))
mse_val = np.mean((orig_arr.astype(float) - stego_arr.astype(float))**2)
print("    MSE                   : {:.4f}".format(mse_val))
print("    Max diff pixel        : {}".format(
    int(np.abs(orig_arr.astype(int) - stego_arr.astype(int)).max())))
print()
print("  File da luu:")
print("    results/stego_image.png  — anh da giau tin")
print("    results/compare.png      — so sanh anh goc | stego")
print("    results/diff_map.png     — ban do sai khac (x10)")
print("    results/keys.json        — 4 khoa K1-K4")
print()
print("  Mo xem:")
print("    eog results/stego_image.png")
print("    eog results/compare.png")
print("    eog results/diff_map.png")
print("=" * 62)
