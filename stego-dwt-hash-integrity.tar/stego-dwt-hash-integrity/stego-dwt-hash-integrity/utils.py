import pywt
import numpy as np

def get_dwt_positions(shape, band='LH'):
    dummy = np.zeros(shape, dtype=np.float64)
    _, (LH, HL, HH) = pywt.dwt2(dummy + 1, 'haar')
    h2, w2 = LH.shape
    positions = []
    if band == 'LH':
        for r in range(h2):
            for c in range(w2):
                positions.append((r, w2 + c))
    elif band == 'HL':
        for r in range(h2):
            for c in range(w2):
                positions.append((h2 + r, c))
    elif band == 'LH+HL':
        for r in range(h2):
            for c in range(w2):
                positions.append((r, w2 + c))
        for r in range(h2):
            for c in range(w2):
                positions.append((h2 + r, c))
    return positions

def embed_bits(arr, positions, bits):
    result = arr.copy()
    for i, bit in enumerate(bits):
        r, c = positions[i]
        result[r, c] = (int(result[r, c]) & ~1) | bit
    return result

def extract_bits(arr, positions, n_bits):
    return [int(arr[r, c]) & 1 for r, c in positions[:n_bits]]
