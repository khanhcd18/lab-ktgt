import hashlib, json, sys, math
import numpy as np
from PIL import Image
from utils import get_dwt_positions, embed_bits

# ================================================================
# SINH VIEN CHINH SUA 2 THAM SO NAY
REGION_SPLIT = 0.75   # Ti le Vung A: 0.5 -> 0.9
EMBED_BAND   = 'LH'   # 'LH', 'HL', hoac 'LH+HL'
# ================================================================

img       = Image.open('input_image.png').convert('L')
arr       = np.array(img, dtype=np.uint8)
H, W      = arr.shape
split_row = int(H * REGION_SPLIT)
region_A  = arr[:split_row, :]
region_B  = arr[split_row:, :]

positions = get_dwt_positions(region_B.shape, EMBED_BAND)
if len(positions) < 256:
    print("[LOI] Vung B qua nho ({} vi tri < 256).".format(len(positions)))
    print("      Giam REGION_SPLIT hoac chon EMBED_BAND = 'LH+HL'")
    sys.exit(1)

hash_hex  = hashlib.sha256(region_A.tobytes()).hexdigest()
hash_bits = []
for ch in hash_hex:
    val = int(ch, 16)
    for bp in range(3, -1, -1):
        hash_bits.append((val >> bp) & 1)

region_B_new            = embed_bits(region_B, positions, hash_bits)
stego_arr               = arr.copy()
stego_arr[split_row:, :] = region_B_new
Image.fromarray(stego_arr).save('stego_image.png')

mse  = np.mean((arr.astype(float) - stego_arr.astype(float))**2)
psnr = 20 * math.log10(255.0 / math.sqrt(mse)) if mse > 0 else float('inf')

json.dump({'region_split': REGION_SPLIT, 'split_row': split_row,
           'embed_band': EMBED_BAND, 'hash_hex': hash_hex,
           'image_shape': [H, W]},
          open('embed_meta.json', 'w'), indent=2)

print("=" * 58)
print("  [TASK 1] NHUNG HASH SHA-256 VAO DWT")
print("=" * 58)
print("  Kich thuoc anh : {}x{} px".format(W, H))
print("  Vung A         : {} dong  (duoc bao ve)".format(split_row))
print("  Vung B         : {} dong  (chua watermark)".format(H - split_row))
print("  Embed band     : {}  |  Capacity: {} vi tri".format(
    EMBED_BAND, len(positions)))
print("  Bit can nhung  : 256 / {} capacity".format(len(positions)))
print("  SHA-256        : {}...{}".format(hash_hex[:16], hash_hex[-16:]))
print("  PSNR           : {:.4f} dB  ({})".format(
    psnr, "TOT" if psnr >= 40 else "CHAP NHAN DUOC" if psnr >= 30 else "THAP"))
print("  Da luu         : stego_image.png")
print("=" * 58)
