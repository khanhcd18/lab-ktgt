import hashlib, json, io, math
import numpy as np
from PIL import Image
from utils import get_dwt_positions, extract_bits

# ================================================================
# TASK 4: SINH VIEN DOC HIEU TUNG DONG CHU THICH
# SAU DO BO DAU # O PHAN [CODE MAU] DE CHAY
# ================================================================

def bits_to_hex_i(bits):
    return ''.join(format(bits[i]*8+bits[i+1]*4+bits[i+2]*2+bits[i+3], 'x')
                   for i in range(0, len(bits), 4))


def verify(arr, split_row, band):
    """
    Ham xac thuc dung chung cho ca 2 kich ban tan cong.
    Tra ve: (ket_qua, so_ky_tu_hash_khac_nhau)
    """
    bits  = extract_bits(arr[split_row:, :],
                         get_dwt_positions(arr[split_row:, :].shape, band), 256)
    h_ext = bits_to_hex_i(bits)
    h_cmp = hashlib.sha256(arr[:split_row, :].tobytes()).hexdigest()
    diff  = sum(a != b for a, b in zip(h_ext, h_cmp))
    return h_ext == h_cmp, diff

    # [CODE MAU - bo dau # de chay]
    # bits  = extract_bits(arr[split_row:, :],
    #                      get_dwt_positions(arr[split_row:, :].shape, band), 256)
    # h_ext = bits_to_hex_i(bits)
    # h_cmp = hashlib.sha256(arr[:split_row, :].tobytes()).hexdigest()
    # diff  = sum(a != b for a, b in zip(h_ext, h_cmp))
    # return h_ext == h_cmp, diff


def psnr(a, b):
    """
    Tinh PSNR giua anh goc va anh bi tan cong.
    PSNR cang cao → anh cang it bi bien dang sau tan cong.
    PSNR cang thap → tan cong cang manh, anh bien dang nhieu.
    """
    # Tinh sai so binh phuong trung binh giua 2 anh
    mse = np.mean((a.astype(float) - b.astype(float))**2)
    # Ap dung cong thuc PSNR = 20*log10(255/sqrt(MSE))
    return 20 * math.log10(255.0 / math.sqrt(mse)) if mse > 0 else float('inf')

    # [CODE MAU - bo dau # de chay]
    # mse = np.mean((a.astype(float) - b.astype(float))**2)
    # return 20 * math.log10(255.0 / math.sqrt(mse)) if mse > 0 else float('inf')


def jpeg_attack(stego_img, quality):
    """
    Mo phong tan cong nen JPEG:
    1. Luu anh vao buffer voi dinh dang JPEG o muc quality cho truoc
    2. Doc lai anh tu buffer → anh da bi nen mat du lieu
    3. JPEG chat luong thap → bien dang nhieu → de bi phat hien TAMPERED
    """
    # Tao buffer trong bo nho (khong luu file ra dia)
    buf = io.BytesIO()
    # Nen anh sang JPEG voi muc quality cho truoc (1-100)
    stego_img.save(buf, format='JPEG', quality=quality)
    buf.seek(0)
    # Doc lai anh da bi nen tu buffer
    return np.array(Image.open(buf).convert('L'), dtype=np.uint8)

    # [CODE MAU - bo dau # de chay]
    # buf = io.BytesIO()
    # stego_img.save(buf, format='JPEG', quality=quality)
    # buf.seek(0)
    # return np.array(Image.open(buf).convert('L'), dtype=np.uint8)


def gaussian_attack(arr, sigma):
    """
    Mo phong tan cong nhieu Gaussian:
    1. Tao ma tran nhieu ngau nhien phan phoi Gaussian (trung binh=0, do lech=sigma)
    2. Cong nhieu vao anh stego
    3. Clip ve khoang [0,255] de giu gia tri pixel hop le
    Sigma cang lon → nhieu cang manh → cang de bi phat hien TAMPERED
    """
    # Tao nhieu Gaussian cung kich thuoc voi anh
    noise = np.random.normal(0, sigma, arr.shape)
    # Cong nhieu vao anh va dam bao gia tri pixel trong [0, 255]
    return np.clip(arr.astype(float) + noise, 0, 255).astype(np.uint8)

    # [CODE MAU - bo dau # de chay]
    # noise = np.random.normal(0, sigma, arr.shape)
    # return np.clip(arr.astype(float) + noise, 0, 255).astype(np.uint8)


# ================================================================

meta       = json.load(open('embed_meta.json'))
split_row  = meta['split_row']
embed_band = meta['embed_band']
stego_img  = Image.open('stego_image.png').convert('L')
stego_arr  = np.array(stego_img, dtype=np.uint8)

print("=" * 62)
print("  [TASK 4] PHAN TICH GIOI HAN HE THONG")
print("=" * 62)

# --- Kich ban A: JPEG ---
print()
print("  [A] TAN CONG JPEG")
print("  Giai thich: JPEG la dinh dang nen mat du lieu (lossy).")
print("  Qua trinh nen lam thay doi gia tri pixel → hash Vung A thay doi.")
print("  JPEG q=100 gan nhu khong mat du lieu, q=50 mat rat nhieu.")
print()
print("  {:>8} {:>12} {:>12} {:>10}".format(
    'Quality', 'PSNR (dB)', 'Hash diff', 'Ket qua'))
print("  " + "-" * 44)

for q in [100, 95, 90, 75, 50]:
    att      = jpeg_attack(stego_img, q)
    ok, diff = verify(att, split_row, embed_band)
    print("  {:>8} {:>12.2f} {:>12} {:>10}".format(
        "q={}".format(q), psnr(stego_arr, att), diff,
        "AUTHENTIC" if ok else "TAMPERED"))

# --- Kich ban B: Gaussian noise ---
print()
print("  [B] TAN CONG NHIEU GAUSSIAN")
print("  Giai thich: Nhieu Gaussian cong ngau nhien vao pixel.")
print("  Du chi sigma=0.1 (nhieu rat nhe), hash van co the thay doi")
print("  vi SHA-256 rat nhay (tinh chat avalanche effect).")
print()
print("  {:>8} {:>12} {:>12} {:>10}".format(
    'Sigma', 'PSNR (dB)', 'Hash diff', 'Ket qua'))
print("  " + "-" * 44)

for sigma in [0.1, 0.5, 1.0, 2.0]:
    att      = gaussian_attack(stego_arr, sigma)
    ok, diff = verify(att, split_row, embed_band)
    print("  {:>8} {:>12.2f} {:>12} {:>10}".format(
        sigma, psnr(stego_arr, att), diff,
        "AUTHENTIC" if ok else "TAMPERED"))

print()
print("=" * 62)
