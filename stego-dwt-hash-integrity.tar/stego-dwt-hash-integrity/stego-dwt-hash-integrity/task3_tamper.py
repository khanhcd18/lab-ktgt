import hashlib, json
import numpy as np
from PIL import Image
from utils import get_dwt_positions, extract_bits

# ================================================================
# TASK 3: SINH VIEN DOC HIEU TUNG DONG CHU THICH
# SAU DO BO DAU # O PHAN [CODE MAU] DE CHAY
# ================================================================

# ================================================================
# SINH VIEN CHINH SUA DE THU NGHIEM
TAMPER_ZONE = 'A'    # 'A' hoac 'B'
TAMPER_ROW  = 100
TAMPER_COL  = 150
TAMPER_SIZE = 10
TAMPER_VAL  = 200
# ================================================================

def bits_to_hex_i(bits):
    """
    Ham noi bo: chuyen 256 bit → hex 64 ky tu.
    Tuong tu bits_to_hex trong task2, dung de kiem tra noi bo.
    """
    return ''.join(format(bits[i]*8+bits[i+1]*4+bits[i+2]*2+bits[i+3], 'x')
                   for i in range(0, len(bits), 4))

    # [CODE MAU - bo dau # de chay]
    # return ''.join(format(bits[i]*8+bits[i+1]*4+bits[i+2]*2+bits[i+3], 'x')
    #                for i in range(0, len(bits), 4))


def verify(arr, split_row, band):
    """
    Xac thuc tinh toan ven cua anh:
    1. Trich xuat 256 bit tu Vung B
    2. Chuyen bit → hex → hash_extracted
    3. Tinh lai SHA-256 cua Vung A → hash_computed
    4. So sanh 2 hash → AUTHENTIC neu khop, TAMPERED neu khac
    """
    # Trich xuat bit tu LSB pixel o Vung B
    bits  = extract_bits(arr[split_row:, :],
                         get_dwt_positions(arr[split_row:, :].shape, band), 256)
    # Chuyen bit → chuoi hex
    h_ext = bits_to_hex_i(bits)
    # Tinh lai hash cua Vung A tu anh can kiem tra
    h_cmp = hashlib.sha256(arr[:split_row, :].tobytes()).hexdigest()
    # Dem so ky tu hex khac nhau giua 2 hash
    diff  = sum(a != b for a, b in zip(h_ext, h_cmp))
    return h_ext == h_cmp, diff

    # [CODE MAU - bo dau # de chay]
    # bits  = extract_bits(arr[split_row:, :],
    #                      get_dwt_positions(arr[split_row:, :].shape, band), 256)
    # h_ext = bits_to_hex_i(bits)
    # h_cmp = hashlib.sha256(arr[:split_row, :].tobytes()).hexdigest()
    # diff  = sum(a != b for a, b in zip(h_ext, h_cmp))
    # return h_ext == h_cmp, diff


# ================================================================

meta       = json.load(open('embed_meta.json'))
split_row  = meta['split_row']
embed_band = meta['embed_band']

arr          = np.array(Image.open('stego_image.png').convert('L'), dtype=np.uint8)
tampered_arr = arr.copy()

r1, r2   = TAMPER_ROW, TAMPER_ROW + TAMPER_SIZE
c1, c2   = TAMPER_COL, TAMPER_COL + TAMPER_SIZE
old_mean = arr[r1:r2, c1:c2].mean()

# Thay the gia tri pixel trong vung duoc chon bang TAMPER_VAL
tampered_arr[r1:r2, c1:c2] = TAMPER_VAL
Image.fromarray(tampered_arr).save('tampered_image.png')

ok, diff = verify(tampered_arr, split_row, embed_band)

print("=" * 58)
print("  [TASK 3] GIA MAO ANH")
print("=" * 58)
print("  Vung tan cong : Vung {}".format(TAMPER_ZONE))
print("  Vi tri        : hang {}-{}, cot {}-{}".format(r1, r2, c1, c2))
print("  So pixel sua  : {}".format(TAMPER_SIZE * TAMPER_SIZE))
print("  Gia tri pixel : {:.1f} → {}".format(old_mean, TAMPER_VAL))
print()
if ok:
    print("  => AUTHENTIC (khong phat hien chinh sua)")
    print("     Giai thich: Vung B bi sua nen hash Vung A khong thay doi")
else:
    print("  => TAMPERED  (phat hien chinh sua!)")
    print("     So ky tu hex hash khac: {}/64".format(diff))
print("=" * 58)
