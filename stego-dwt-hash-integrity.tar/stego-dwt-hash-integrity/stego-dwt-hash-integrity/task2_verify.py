import hashlib, json
import numpy as np
from PIL import Image
from utils import get_dwt_positions, extract_bits

# ================================================================
# TASK 2: SINH VIEN DOC HIEU TUNG DONG CHU THICH
# SAU DO BO DAU # O PHAN [CODE MAU] DE CHAY
# ================================================================

def bits_to_hex(bits):
    """
    Chuyen 256 bit → chuoi hex 64 ky tu.
    Xu ly tung nhom 4 bit (nibble) → 1 ky tu hex.

    Vi du: [1,0,1,0] → val = 1*8+0*4+1*2+0 = 10 → 'a'
            [0,0,1,1] → val = 0*8+0*4+1*2+1 = 3  → '3'
    Ket qua: 'a3'
    """
    result = ''
    for i in range(0, len(bits), 4):
        # Tinh gia tri thap phan tu 4 bit lien tiep
        # Bit dau co trong so cao nhat (8), bit cuoi trong so thap nhat (1)
        val = bits[i]*8 + bits[i+1]*4 + bits[i+2]*2 + bits[i+3]
        # format(val, 'x') chuyen so nguyen → 1 ky tu hex
        result += format(val, 'x')
    return result

    # [CODE MAU - bo dau # de chay]
    # result = ''
    # for i in range(0, len(bits), 4):
    #     val = bits[i]*8 + bits[i+1]*4 + bits[i+2]*2 + bits[i+3]
    #     result += format(val, 'x')
    # return result


def compute_hash_region(arr, split_row):
    """
    Tinh SHA-256 cua Vung A (phan anh duoc bao ve, khong bi nhung).

    Vung A = arr[:split_row, :] — phan phia tren cua anh
    SHA-256 nhan vao bytes, nen phai goi .tobytes() truoc
    """
    # Cat mang lay Vung A (tu dong 0 den split_row)
    region_A = arr[:split_row, :]
    # Chuyen numpy array → bytes → tinh SHA-256 → tra ve hex string
    return hashlib.sha256(region_A.tobytes()).hexdigest()

    # [CODE MAU - bo dau # de chay]
    # region_A = arr[:split_row, :]
    # return hashlib.sha256(region_A.tobytes()).hexdigest()

# ================================================================

meta       = json.load(open('embed_meta.json'))
split_row  = meta['split_row']
embed_band = meta['embed_band']

arr       = np.array(Image.open('stego_image.png').convert('L'), dtype=np.uint8)
region_B  = arr[split_row:, :]
positions = get_dwt_positions(region_B.shape, embed_band)
bits      = extract_bits(region_B, positions, 256)

hash_extracted = bits_to_hex(bits)
hash_computed  = compute_hash_region(arr, split_row)

print("=" * 58)
print("  [TASK 2] XAC THUC TINH TOAN VEN")
print("=" * 58)
print("  Bit trich xuat : 256 bit tu Vung B (band {})".format(embed_band))
print("  Hash trich xuat: {}".format(hash_extracted))
print("  Hash tinh lai  : {}".format(hash_computed))

if hash_extracted == hash_computed:
    print("  => AUTHENTIC — Anh toan ven, chua bi chinh sua.")
else:
    diff = sum(a != b for a, b in zip(hash_extracted, hash_computed))
    print("  => TAMPERED  — Phat hien chinh sua!")
    print("     So ky tu hex khac nhau: {}/64".format(diff))
print("=" * 58)
