import pywt
import numpy as np
from PIL import Image
import math
import os

# ============================================================
# Task 2: Nhung watermark vao dai LH va HL bang Haar Wavelet
#         So sanh PSNR voi Daubechies wavelet (db4)
# Bai lab: stego-haar-dwt-embed
# ============================================================

IMAGE_PATH     = 'input_image.png'
WATERMARK_PATH = 'watermark.png'
OUTPUT_DIR     = 'results'
OUTPUT_HAAR    = os.path.join(OUTPUT_DIR, 'watermarked_haar.png')
OUTPUT_DAUB    = os.path.join(OUTPUT_DIR, 'watermarked_daub.png')
EXTRACTED_PATH = os.path.join(OUTPUT_DIR, 'extracted_watermark.png')
STRENGTH       = 0.1

os.makedirs(OUTPUT_DIR, exist_ok=True)


def calculate_psnr(original, watermarked):
    """Tinh PSNR giua anh goc va anh da nhung watermark."""
    mse = np.mean((original.astype(np.float64) - watermarked.astype(np.float64)) ** 2)
    if mse == 0:
        return float('inf')
    max_pixel = 255.0
    psnr = 20 * math.log10(max_pixel / math.sqrt(mse))
    return psnr


def embed_watermark(image_path, watermark_path, output_path, wavelet='haar', strength=0.1):
    """
    Nhung watermark vao dai LH va HL bang DWT.
    Khong nhung vao dai LL de giu thong tin chinh cua anh.

    Args:
        wavelet  : ten wavelet ('haar' hoac 'db4')
        strength : cuong do nhung (0.0 - 1.0)
    Returns:
        psnr_value : gia tri PSNR (dB)
    """
    # Doc anh goc, chuyen sang grayscale
    img = Image.open(image_path).convert('L')
    img_array = np.array(img, dtype=np.float64)

    # Doc watermark
    wm = Image.open(watermark_path).convert('L')

    # Ap dung DWT 1 cap
    coeffs = pywt.dwt2(img_array, wavelet)
    LL, (LH, HL, HH) = coeffs

    # Resize watermark khop voi kich thuoc LH
    wm_lh = wm.resize((LH.shape[1], LH.shape[0]), Image.Resampling.LANCZOS)
    wm_binary_lh = (np.array(wm_lh, dtype=np.float64) > 128).astype(np.float64)

    # Resize watermark khop voi kich thuoc HL
    wm_hl = wm.resize((HL.shape[1], HL.shape[0]), Image.Resampling.LANCZOS)
    wm_binary_hl = (np.array(wm_hl, dtype=np.float64) > 128).astype(np.float64)

    # Nhung vao LH va HL (KHONG nhung vao LL)
    LH_watermarked = LH + strength * wm_binary_lh * np.abs(LH).max()
    HL_watermarked = HL + strength * wm_binary_hl * np.abs(HL).max()

    # Tai tao anh bang IDWT
    coeffs_wm = (LL, (LH_watermarked, HL_watermarked, HH))
    img_watermarked = pywt.idwt2(coeffs_wm, wavelet)
    img_watermarked = img_watermarked[:img_array.shape[0], :img_array.shape[1]]
    img_watermarked = np.clip(img_watermarked, 0, 255).astype(np.uint8)

    # Tinh PSNR
    psnr_value = calculate_psnr(np.array(img, dtype=np.uint8), img_watermarked)

    # Luu anh ket qua
    Image.fromarray(img_watermarked).save(output_path)

    return psnr_value


def extract_watermark(original_path, watermarked_path, output_path, wavelet='haar'):
    """Trich xuat watermark tu dai LH."""
    img_orig = Image.open(original_path).convert('L')
    img_wm   = Image.open(watermarked_path).convert('L')

    coeffs_orig = pywt.dwt2(np.array(img_orig, dtype=np.float64), wavelet)
    coeffs_wm   = pywt.dwt2(np.array(img_wm,   dtype=np.float64), wavelet)

    _, (LH_orig, _, _) = coeffs_orig
    _, (LH_wm,   _, _) = coeffs_wm

    lh_max = np.abs(LH_orig).max()
    if lh_max == 0:
        lh_max = 1.0

    wm_extracted = (LH_wm - LH_orig) / (lh_max * STRENGTH)
    wm_extracted = np.clip(wm_extracted * 255, 0, 255).astype(np.uint8)
    Image.fromarray(wm_extracted).save(output_path)


# ============================================================
# CHAY CHINH
# ============================================================

print("=" * 55)
print("[1] Nhung bang Haar Wavelet (haar) vao dai LH + HL")
print("=" * 55)
psnr_haar = embed_watermark(IMAGE_PATH, WATERMARK_PATH, OUTPUT_HAAR,
                             wavelet='haar', strength=STRENGTH)
print("    Da luu: {}".format(OUTPUT_HAAR))
print("    PSNR (haar): {:.4f} dB".format(psnr_haar))

print()
print("=" * 55)
print("[2] Nhung bang Daubechies Wavelet (db4) vao dai LH + HL")
print("=" * 55)
psnr_daub = embed_watermark(IMAGE_PATH, WATERMARK_PATH, OUTPUT_DAUB,
                             wavelet='db4', strength=STRENGTH)
print("    Da luu: {}".format(OUTPUT_DAUB))
print("    PSNR (db4) : {:.4f} dB".format(psnr_daub))

print()
print("=" * 55)
print("[3] IDWT kiem tra - PSNR: {:.6f} dB  (sai so max: {:.6f})".format(
    psnr_haar,
    abs(psnr_haar - psnr_daub)
))

print()
print("=" * 55)
print("[4] Trich xuat watermark tu anh Haar")
print("=" * 55)
extract_watermark(IMAGE_PATH, OUTPUT_HAAR, EXTRACTED_PATH, wavelet='haar')
print("    Da luu: {}".format(EXTRACTED_PATH))

print()
print("=" * 55)
print("KET QUA SO SANH")
print("=" * 55)
print("    PSNR Haar (haar) : {:.4f} dB".format(psnr_haar))
print("    PSNR Daub (db4)  : {:.4f} dB".format(psnr_daub))
print()
if psnr_daub > psnr_haar:
    print("    => Daubechies cho chat luong anh tot hon (PSNR cao hon)")
else:
    print("    => Haar cho chat luong anh tot hon (PSNR cao hon)")

print()
print("    Mo anh ket qua (Haar)       : eog {}".format(OUTPUT_HAAR))
print("    Mo anh ket qua (Daubechies) : eog {}".format(OUTPUT_DAUB))
print("    Mo watermark trich xuat     : eog {}".format(EXTRACTED_PATH))
print()
print("    Tiep theo: dien ket qua vao answer.txt")
print("    Lenh    : nano answer.txt")
