import pywt
import numpy as np
from PIL import Image
import os
import math

# ============================================================
# Task 1: Truc quan hoa cac dai tan so DWT (Haar Wavelet)
# Bai lab: stego-haar-dwt-embed
# ============================================================

IMAGE_PATH  = 'input_image.png'
OUTPUT_DIR  = 'results'
OUTPUT_FILE = os.path.join(OUTPUT_DIR, 'dwt_subbands.png')

os.makedirs(OUTPUT_DIR, exist_ok=True)

# --- Doc anh goc ---
img = Image.open(IMAGE_PATH).convert('L')
img_array = np.array(img, dtype=np.float64)

print("=" * 50)
print("[1] Doc anh goc: {}".format(IMAGE_PATH))
print("    Kich thuoc : {} x {}".format(img_array.shape[1], img_array.shape[0]))

# --- Ap dung DWT 1 cap voi Haar wavelet ---
coeffs = pywt.dwt2(img_array, 'haar')
LL, (LH, HL, HH) = coeffs

print("\n[2] Ap dung DWT voi Haar wavelet")
print("    Dai LL (Low-Low)   : {} x {} | Nang luong: {:.0f} ({:.1f}%)".format(
    LL.shape[1], LL.shape[0],
    np.sum(LL**2),
    100 * np.sum(LL**2) / (np.sum(LL**2) + np.sum(LH**2) + np.sum(HL**2) + np.sum(HH**2))
))
print("    Dai LH (Low-High)  : {} x {} | Nang luong: {:.0f} ({:.1f}%)".format(
    LH.shape[1], LH.shape[0],
    np.sum(LH**2),
    100 * np.sum(LH**2) / (np.sum(LL**2) + np.sum(LH**2) + np.sum(HL**2) + np.sum(HH**2))
))
print("    Dai HL (High-Low)  : {} x {} | Nang luong: {:.0f} ({:.1f}%)".format(
    HL.shape[1], HL.shape[0],
    np.sum(HL**2),
    100 * np.sum(HL**2) / (np.sum(LL**2) + np.sum(LH**2) + np.sum(HL**2) + np.sum(HH**2))
))
print("    Dai HH (High-High) : {} x {} | Nang luong: {:.0f} ({:.1f}%)".format(
    HH.shape[1], HH.shape[0],
    np.sum(HH**2),
    100 * np.sum(HH**2) / (np.sum(LL**2) + np.sum(LH**2) + np.sum(HL**2) + np.sum(HH**2))
))

# --- Chuan hoa tung dai de hien thi ---
def normalize_band(band):
    b = band.copy()
    b_min, b_max = b.min(), b.max()
    if b_max - b_min == 0:
        return np.zeros_like(b, dtype=np.uint8)
    return ((b - b_min) / (b_max - b_min) * 255).astype(np.uint8)

ll_img = normalize_band(LL)
lh_img = normalize_band(LH)
hl_img = normalize_band(HL)
hh_img = normalize_band(HH)

# --- Ghep 4 dai thanh 1 anh 2x2 ---
h, w = ll_img.shape
gap = 4  # pixel trang ngan each dai

canvas_h = h * 2 + gap * 3
canvas_w = w * 2 + gap * 3
canvas = np.ones((canvas_h, canvas_w), dtype=np.uint8) * 200  # nen xam nhat

# Vi tri tung dai
canvas[gap:gap+h,         gap:gap+w]           = ll_img   # top-left  : LL
canvas[gap:gap+h,         gap+w+gap:gap+w+gap+w] = lh_img  # top-right : LH
canvas[gap+h+gap:gap+h+gap+h, gap:gap+w]         = hl_img  # bot-left  : HL
canvas[gap+h+gap:gap+h+gap+h, gap+w+gap:gap+w+gap+w] = hh_img  # bot-right: HH

result_img = Image.fromarray(canvas)
result_img.save(OUTPUT_FILE)

print("\n[3] Da luu anh ket qua: {}".format(OUTPUT_FILE))
print("\n" + "=" * 50)
print("KET QUA")
print("=" * 50)
print("  Cau hoi 1.1: Dai LL trong nhu the nao so voi anh goc?")
print("  Cau hoi 1.2: Dai HL the hien dac trung gi cua anh?")
print("")
print("  Mo anh ket qua:  eog {}".format(OUTPUT_FILE))
print("  Tiep theo       :  python3 task2_embed.py")
