import pywt
import numpy as np
from PIL import Image
import json, math, io, os

os.makedirs('results', exist_ok=True)

info   = json.load(open('results/embed_info.json'))
ALPHA  = info['alpha']
U      = np.load('results/U.npy')
S_orig = np.load('results/S_orig.npy')
Vt     = np.load('results/Vt.npy')
S_wm   = np.load('results/S_wm.npy')
orig   = np.load('results/orig.npy').astype(np.uint8)
LH_o   = np.load('results/LH.npy')

stego_svd = np.array(Image.open('results/stego_svd.png').convert('L'), dtype=np.uint8)
stego_dwt = np.array(Image.open('results/stego_dwt.png').convert('L'), dtype=np.uint8)
wm_orig   = np.array(Image.open('watermark.png').convert('L')
                     .resize((64, 64), Image.LANCZOS), dtype=np.uint8)


def normalized_correlation(wm_ref, wm_ext):
    # Cong thuc NC:
    #          sum(W * W')
    # NC = -------------------------
    #       sqrt(sum(W^2) * sum(W'^2))
    w1    = wm_ref.astype(float) / 255.0
    w2    = wm_ext.astype(float) / 255.0
    num   = np.sum(w1 * w2)
    denom = math.sqrt(np.sum(w1**2) * np.sum(w2**2))
    return float(num / denom) if denom > 0 else 0.0


def extract_svd(attacked, U, S_orig, Vt, S_wm, alpha):
    # Trich xuat nguoc:
    # 1. DWT → LL_attacked
    # 2. SVD(LL_attacked) → S_att
    # 3. S_wm_ext = (S_att - S_orig) / alpha
    # 4. Tai tao watermark tu S_wm_ext
    LL_a        = pywt.dwt2(attacked.astype(np.float64), 'haar')[0]
    _, S_att, _ = np.linalg.svd(LL_a, full_matrices=False)
    n           = min(len(S_att), len(S_orig))
    S_wm_ext    = (S_att[:n] - S_orig[:n]) / alpha
    wm_vec = np.abs(S_wm_ext)
    wm_vec = wm_vec / wm_vec.max() * 255 if wm_vec.max() > 0 else wm_vec
    U_wm  = np.load('results/U_wm.npy')
    Vt_wm = np.load('results/Vt_wm.npy')
    k     = min(len(S_wm_ext), U_wm.shape[1], Vt_wm.shape[0])
    wm_rec = U_wm[:, :k] @ np.diag(S_wm_ext[:k]) @ Vt_wm[:k, :]
    return np.array(Image.fromarray(
        np.clip(wm_rec, 0, 255).astype(np.uint8)
    ).resize((64, 64), Image.LANCZOS))

def extract_dwt(attacked, orig_lh, alpha):
    # Trich xuat nguoc alpha blending:
    # LH_extracted = (LH_attacked - LH_orig) / (alpha * max|LH_orig|)
    LH_a  = pywt.dwt2(attacked.astype(np.float64), 'haar')[1][0]
    mx    = np.abs(orig_lh).max()
    diff  = np.clip((LH_a - orig_lh) / (alpha * mx) * 255, 0, 255).astype(np.uint8)
    return np.array(Image.fromarray(diff).resize((64, 64), Image.LANCZOS))


def apply_attack(img_arr, atype, param):
    if atype == 'jpeg':
        buf = io.BytesIO()
        Image.fromarray(img_arr).save(buf, format='JPEG', quality=param)
        buf.seek(0)
        return np.array(Image.open(buf).convert('L'), dtype=np.uint8)
    elif atype == 'gauss':
        noise = np.random.normal(0, param, img_arr.shape)
        return np.clip(img_arr.astype(float) + noise, 0, 255).astype(np.uint8)
    return img_arr.copy()


ATTACKS = [
    ('Khong tan cong', None,    None),
    ('JPEG  q=90',     'jpeg',  90),
    ('JPEG  q=75',     'jpeg',  75),
    ('JPEG  q=50',     'jpeg',  50),
    ('JPEG  q=25',     'jpeg',  25),
    ('Gauss s=1.0',    'gauss', 1.0),
    ('Gauss s=3.0',    'gauss', 3.0),
    ('Gauss s=5.0',    'gauss', 5.0),
]

print("=" * 70)
print("  [TASK 5] SO SANH DO BEN: DWT+SVD vs DWT THUAN TUY")
print("=" * 70)
print("  {:18} {:>12} {:>12} {:>14}".format(
    'Tan cong', 'NC (DWT+SVD)', 'NC (DWT)', 'Phuong phap tot'))
print("  " + "-" * 60)

best_svd = []
for name, atype, param in ATTACKS:
    att_svd = apply_attack(stego_svd, atype, param) if atype else stego_svd.copy()
    att_dwt = apply_attack(stego_dwt, atype, param) if atype else stego_dwt.copy()

    wm_svd = extract_svd(att_svd, U, S_orig, Vt, S_wm, ALPHA)
    wm_dwt = extract_dwt(att_dwt, LH_o, ALPHA)

    # Luu watermark trich xuat cho lan tan cong dau tien (khong tan cong)
    if atype is None:
        Image.fromarray(wm_svd).save('results/wm_extracted_svd.png')
        Image.fromarray(wm_dwt).save('results/wm_extracted_dwt.png')

    nc_svd = normalized_correlation(wm_orig, wm_svd)
    nc_dwt = normalized_correlation(wm_orig, wm_dwt)

    if nc_svd > nc_dwt + 0.01:
        better = "DWT+SVD"
        best_svd.append(name)
    elif nc_dwt > nc_svd + 0.01:
        better = "DWT thuan tuy"
    else:
        better = "Tuong duong"

    print("  {:18} {:>12.4f} {:>12.4f} {:>14}".format(
        name, nc_svd, nc_dwt, better))

print()
print("  DWT+SVD ben hon o: {}".format(
    ', '.join(best_svd) if best_svd else "Khong co trong test nay"))
print()
print("  NC >= 0.90: Tot  |  NC >= 0.75: Chap nhan  |  NC < 0.75: Kem")
print()
print("  Watermark trich xuat (khong tan cong):")
print("    results/wm_extracted_svd.png")
print("    results/wm_extracted_dwt.png")
print("=" * 70)

