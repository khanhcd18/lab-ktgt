import pywt
import numpy as np
from PIL import Image
import json, math, os

os.makedirs('results', exist_ok=True)

info  = json.load(open('results/embed_info.json'))
ALPHA = info['alpha']

orig = np.load('results/orig.npy')
LL   = np.load('results/LL.npy')
LH   = np.load('results/LH.npy')
HL   = np.load('results/HL.npy')
HH   = np.load('results/HH.npy')
H, W = orig.shape

wm     = Image.open('watermark.png').convert('L')
wm_arr = np.array(wm, dtype=np.float64)


def embed_alpha_blending(lh, hl, watermark, alpha):
    # Resize watermark ve kich thuoc cua dai LH/HL
    wm_r   = np.array(Image.fromarray(watermark.astype(np.uint8))
                      .resize((lh.shape[1], lh.shape[0]), Image.LANCZOS),
                      dtype=np.float64)
    # Nhi phan hoa watermark: pixel > 128 → 1, con lai → 0
    wm_bin = (wm_r > 128).astype(np.float64)
    # Cong thuc alpha blending:
    # band_new = band + alpha * wm_binary * max(|band|)
    LH_new = lh + alpha * wm_bin * np.abs(lh).max()
    HL_new = hl + alpha * wm_bin * np.abs(hl).max()
    return LH_new, HL_new


LH_new, HL_new = embed_alpha_blending(LH, HL, wm_arr, ALPHA)

stego = pywt.idwt2((LL, (LH_new, HL_new, HH)), 'haar')
stego = np.clip(stego, 0, 255).astype(np.uint8)[:H, :W]
Image.fromarray(stego).save('results/stego_dwt.png')

diff = np.abs(orig - stego.astype(float))
Image.fromarray(np.clip(diff * 20, 0, 255).astype(np.uint8)).save(
    'results/diff_dwt.png')

mse      = np.mean((orig - stego.astype(float))**2)
psnr_dwt = 20 * math.log10(255.0 / math.sqrt(mse)) if mse > 0 else float('inf')

psnr_svd = None
try:
    s = np.array(Image.open('results/stego_svd.png').convert('L'))
    m = np.mean((orig - s.astype(float))**2)
    psnr_svd = 20 * math.log10(255.0 / math.sqrt(m)) if m > 0 else float('inf')
except:
    pass

print("=" * 55)
print("  [TASK 4] NHUNG DWT THUAN TUY (baseline so sanh)")
print("=" * 55)
print("  Alpha             : {}".format(ALPHA))
print("  Phuong phap       : Alpha blending vao LH + HL")
print("  PSNR DWT thuan tuy: {:.4f} dB".format(psnr_dwt))
if psnr_svd:
    print("  PSNR DWT+SVD      : {:.4f} dB".format(psnr_svd))
    print("  PSNR cao hon      : {}".format(
        "DWT+SVD" if psnr_svd > psnr_dwt else "DWT thuan tuy"))
print("  Max diff pixel    : {}".format(int(diff.max())))
print()
print("  Da luu:")
print("    results/stego_dwt.png  — anh stego DWT thuan tuy")
print("    results/diff_dwt.png   — ban do sai khac (x20)")
print("=" * 55)
