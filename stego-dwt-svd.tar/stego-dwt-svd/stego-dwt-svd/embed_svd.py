import pywt
import numpy as np
from PIL import Image
import json, math, os

os.makedirs('results', exist_ok=True)

# ================================================================
# SINH VIEN MO FILE DOC HIEU CODE TRUOC KHI CHAY:
#   nano task3_embed_svd.py
#
# Chu y hieu ro 3 ham chinh:
#   get_singular_values()       — lay S_wm tu watermark
#   embed_into_singular_values()— cong alpha*S_wm vao S_orig
#   reconstruct_ll()            — tai tao LL tu U, S_new, Vt
# ================================================================

# ================================================================
# SINH VIEN CHINH SUA THAM SO NAY
ALPHA = 0.1   # Cuong do nhung (0.05 - 0.3)
# ================================================================

orig = np.load('results/orig.npy')
LL   = np.load('results/LL.npy')
LH   = np.load('results/LH.npy')
HL   = np.load('results/HL.npy')
HH   = np.load('results/HH.npy')
U    = np.load('results/U.npy')
S    = np.load('results/S.npy')
Vt   = np.load('results/Vt.npy')
H, W = orig.shape

wm     = Image.open('watermark.png').convert('L')
wm_arr = np.array(wm.resize((LL.shape[1], LL.shape[0]), Image.LANCZOS),
                  dtype=np.float64)
U_wm, S_wm, Vt_wm = np.linalg.svd(wm_arr, full_matrices=False)
np.save('results/U_wm.npy',  U_wm)
np.save('results/Vt_wm.npy', Vt_wm)
np.save('results/S_wm.npy',  S_wm)

def get_singular_values(matrix):
    # Phan tich SVD watermark, chi lay S_wm
    # matrix = U_wm x diag(S_wm) x Vt_wm
    # Chi can S_wm de nhung — bo qua U_wm va Vt_wm
    _, S_wm, _ = np.linalg.svd(matrix, full_matrices=False)
    return S_wm


def embed_into_singular_values(S_orig, S_wm, alpha):
    # Cong thuc nhung: S_new[i] = S_orig[i] + alpha * S_wm[i]
    # S_orig: gia tri ky di goc cua LL
    # S_wm  : gia tri ky di cua watermark
    # alpha : he so pha tron
    n          = min(len(S_orig), len(S_wm))
    S_new      = S_orig.copy()
    S_new[:n]  = S_orig[:n] + alpha * S_wm[:n]
    return S_new


def reconstruct_ll(U, S_new, Vt):
    # Tai tao LL sau khi da sua S:
    # LL_new = U x diag(S_new) x Vt
    return U @ np.diag(S_new) @ Vt


S_wm   = get_singular_values(wm_arr)
S_new  = embed_into_singular_values(S, S_wm, ALPHA)
LL_new = reconstruct_ll(U, S_new, Vt)

stego  = pywt.idwt2((LL_new, (LH, HL, HH)), 'haar')
stego  = np.clip(stego, 0, 255).astype(np.uint8)[:H, :W]
Image.fromarray(stego).save('results/stego_svd.png')

# Luu diff rieng (phong dai x20 de nhin ro)
diff = np.abs(orig - stego.astype(float))
Image.fromarray(np.clip(diff * 20, 0, 255).astype(np.uint8)).save(
    'results/diff_svd.png')

np.save('results/S_wm.npy',   S_wm)
np.save('results/S_orig.npy', S.copy())
with open('results/embed_info.json', 'w') as f:
    json.dump({'alpha': ALPHA, 'H': H, 'W': W}, f)

mse  = np.mean((orig - stego.astype(float))**2)
psnr = 20 * math.log10(255.0 / math.sqrt(mse)) if mse > 0 else float('inf')

print("=" * 55)
print("  [TASK 3] NHUNG WATERMARK VAO SIGMA (DWT+SVD)")
print("=" * 55)
print("  Alpha         : {}".format(ALPHA))
print("  S_orig[0]     : {:.2f}".format(S[0]))
print("  S_wm[0]       : {:.2f}".format(S_wm[0]))
print("  S_new[0]      : {:.2f}".format(S_new[0]))
print("  PSNR          : {:.4f} dB".format(psnr))
print("  Max diff pixel: {}".format(int(diff.max())))
print()
print("  Da luu:")
print("    results/stego_svd.png   — anh stego DWT+SVD")
print("    results/diff_svd.png    — ban do sai khac (x20)")
print("=" * 55)
