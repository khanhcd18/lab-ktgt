import numpy as np
from PIL import Image
import os

os.makedirs('results', exist_ok=True)

LL = np.load('results/LL.npy')

# Phan tich SVD cua dai LL
# LL = U x diag(S) x Vt
# U, Vt: ma tran truc giao — giu thong tin huong
# S    : vector gia tri ky di, sap xep giam dan
U, S, Vt = np.linalg.svd(LL, full_matrices=False)

np.save('results/U.npy',     U)
np.save('results/S.npy',     S)
np.save('results/Vt.npy',    Vt)
np.save('results/S_orig.npy', S.copy())

total_energy = np.sum(S**2)
cumulative   = np.cumsum(S**2) / total_energy * 100
k90 = int(np.searchsorted(cumulative, 90.0)) + 1
k95 = int(np.searchsorted(cumulative, 95.0)) + 1
k99 = int(np.searchsorted(cumulative, 99.0)) + 1

# Tai tao LL voi top-k sigma, luu tung file rieng
def to_img(arr):
    mn, mx = arr.min(), arr.max()
    if mx == mn:
        return np.zeros_like(arr, dtype=np.uint8)
    return ((arr - mn) / (mx - mn) * 255).astype(np.uint8)

for k, label in [(10, 'k10'), (50, 'k50'), (len(S), 'full')]:
    rec = U[:, :k] @ np.diag(S[:k]) @ Vt[:k, :]
    Image.fromarray(to_img(rec)).save('results/svd_recon_{}.png'.format(label))

print("=" * 58)
print("  [TASK 2] PHAN TICH SVD DAI LL")
print("=" * 58)
print("  Kich thuoc LL    : {}x{}".format(LL.shape[1], LL.shape[0]))
print("  So gia tri ky di : {}".format(len(S)))
print()
print("  Top 10 sigma:")
for i in range(min(10, len(S))):
    print("    sigma_{:<3}: {:>10.2f}   (tich luy {:.2f}%)".format(
        i+1, S[i], cumulative[i]))
print()
print("  Can bao nhieu sigma de giu du nang luong:")
print("    90%: {} sigma   95%: {} sigma   99%: {} sigma".format(k90, k95, k99))
print()
print("  Tai tao LL voi top-k sigma (xem su khac biet):")
print("    results/svd_recon_k10.png   (chi dung 10 sigma)")
print("    results/svd_recon_k50.png   (chi dung 50 sigma)")
print("    results/svd_recon_full.png  (day du sigma)")
print("=" * 58)
