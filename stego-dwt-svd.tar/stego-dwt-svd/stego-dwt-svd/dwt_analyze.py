import pywt
import numpy as np
from PIL import Image
import os

os.makedirs('results', exist_ok=True)

img = Image.open('input_image.png').convert('L')
arr = np.array(img, dtype=np.float64)
H, W = arr.shape

coeffs = pywt.dwt2(arr, 'haar')
LL, (LH, HL, HH) = coeffs

np.save('results/LL.npy', LL)
np.save('results/LH.npy', LH)
np.save('results/HL.npy', HL)
np.save('results/HH.npy', HH)
np.save('results/orig.npy', arr)

def normalize(band):
    b = band.copy()
    mn, mx = b.min(), b.max()
    if mx == mn:
        return np.zeros_like(b, dtype=np.uint8)
    return ((b - mn) / (mx - mn) * 255).astype(np.uint8)

# Luu tung dai thanh file anh rieng biet
Image.fromarray(normalize(LL)).save('results/band_LL.png')
Image.fromarray(normalize(LH)).save('results/band_LH.png')
Image.fromarray(normalize(HL)).save('results/band_HL.png')
Image.fromarray(normalize(HH)).save('results/band_HH.png')

total = np.sum(LL**2)+np.sum(LH**2)+np.sum(HL**2)+np.sum(HH**2)

print("=" * 55)
print("  [TASK 1] PHAN TICH DWT HAAR")
print("=" * 55)
print("  Anh goc  : {}x{} px".format(W, H))
print("  Moi dai  : {}x{} px".format(LL.shape[1], LL.shape[0]))
print()
print("  Dai    Nang luong        Ty le")
print("  " + "-" * 38)
for name, band in [('LL', LL), ('LH', LH), ('HL', HL), ('HH', HH)]:
    e = np.sum(band**2)
    print("  {:4}   {:>14.0f}   {:>6.2f}%".format(name, e, 100*e/total))
print()
print("  Da luu 4 file anh:")
print("    results/band_LL.png  results/band_LH.png")
print("    results/band_HL.png  results/band_HH.png")
print("=" * 55)
