import pywt, numpy as np, json, math
from PIL import Image

# ================================================================
#  TASK 3: IDWT TAO ANH STEGO, TINH PSNR / MSE
#  - Ghep lai 4 dai (3 dai goc + 1 dai da nhung)
#  - IDWT → anh stego
#  - So sanh voi anh goc → PSNR, MSE
# ================================================================

keys    = json.load(open('keys.json'))
DELTA   = keys['DELTA']
SUBBAND = keys['SUBBAND']

cover   = np.array(Image.open('cover_image.png').convert('L'), dtype=np.float64)
H, W    = cover.shape

LL         = np.load('results/LL.npy')
LH         = np.load('results/LH.npy')
HL         = np.load('results/HL.npy')
HH         = np.load('results/HH.npy')
band_stego = np.load('results/band_stego.npy')

# Ghep lai theo subband da nhung
if SUBBAND == 'LH':
    stego_f = pywt.idwt2((LL, (band_stego, HL, HH)), 'haar')
elif SUBBAND == 'HL':
    stego_f = pywt.idwt2((LL, (LH, band_stego, HH)), 'haar')
else:
    stego_f = pywt.idwt2((LL, (LH, HL, band_stego)), 'haar')

stego_uint8 = np.clip(stego_f, 0, 255).astype(np.uint8)[:H, :W]
Image.fromarray(stego_uint8).save('stego_image.png')

# Tinh PSNR / MSE
diff  = cover - stego_f[:H, :W]
mse   = np.mean(diff ** 2)
psnr  = 20 * math.log10(255.0 / math.sqrt(mse)) if mse > 0 else 999
mae   = np.mean(np.abs(diff))
maxd  = np.max(np.abs(diff))

# Phan tich pixel bi thay doi
n_changed = np.sum(np.abs(diff) > 0.5)
pct_chg   = 100 * n_changed / (H * W)

print('  Subband nhung    : {}'.format(SUBBAND))
print('  DELTA            : {}'.format(DELTA))
print()
print('  CHAT LUONG ANH STEGO:')
print('  MSE              : {:.6f}'.format(mse))
print('  PSNR             : {:.4f} dB'.format(psnr))
print('  MAE              : {:.6f}'.format(mae))
print('  Max pixel diff   : {:.4f}'.format(maxd))
print()
print('  Danh gia PSNR    : {}'.format(
    'Rat tot  (> 50 dB)' if psnr > 50 else
    'Tot      (> 40 dB)' if psnr > 40 else
    'Chap nhan(> 30 dB)' if psnr > 30 else
    'Kem      (< 30 dB)'))
print()
print('  PHAN TICH PIXEL:')
print('  Tong pixel       : {}'.format(H * W))
print('  Pixel bi thay doi: {} ({:.2f}%)'.format(n_changed, pct_chg))
print('  Pixel khong doi  : {} ({:.2f}%)'.format(H*W - n_changed, 100 - pct_chg))
print()
print('  Da luu: stego_image.png')
print('  => Ghi vao answer.txt: PSNR = {:.2f} dB'.format(psnr))
