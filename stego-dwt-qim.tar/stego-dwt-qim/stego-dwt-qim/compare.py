import pywt, numpy as np, json, math
from PIL import Image

# ================================================================
#  TASK 5: PHAN TICH TOAN DIEN ANH GOC vs ANH STEGO
#  - So sanh histogram
#  - Phan tich nang luong tung dai DWT
#  - Danh gia tinh an cua stego
# ================================================================

keys    = json.load(open('keys.json'))
DELTA   = keys['DELTA']
SUBBAND = keys['SUBBAND']
n_bits  = keys['n_bits']

cover  = np.array(Image.open('cover_image.png').convert('L'), dtype=np.float64)
stego  = np.array(Image.open('stego_image.png').convert('L'), dtype=np.float64)
H, W   = cover.shape

# DWT ca 2 anh
LL_c,(LH_c,HL_c,HH_c) = pywt.dwt2(cover, 'haar')
LL_s,(LH_s,HL_s,HH_s) = pywt.dwt2(stego, 'haar')

band_c = {'LH':LH_c,'HL':HL_c,'HH':HH_c}[SUBBAND]
band_s = {'LH':LH_s,'HL':HL_s,'HH':HH_s}[SUBBAND]

# Histogram
hist_c, _ = np.histogram(cover.flatten(), bins=256, range=(0,255))
hist_s, _ = np.histogram(stego.flatten(), bins=256, range=(0,255))
hist_diff  = np.sum(np.abs(hist_c.astype(int) - hist_s.astype(int)))

# Nang luong tung dai
total_c = np.sum(LL_c**2)+np.sum(LH_c**2)+np.sum(HL_c**2)+np.sum(HH_c**2)
total_s = np.sum(LL_s**2)+np.sum(LH_s**2)+np.sum(HL_s**2)+np.sum(HH_s**2)

# So he so thay doi trong dai nhung
n_changed_band = np.sum(np.abs(band_s - band_c) > 0.01)

# PSNR
mse  = np.mean((cover - stego)**2)
psnr = 20 * math.log10(255.0 / math.sqrt(mse)) if mse > 0 else 999

print('=' * 68)
print('  [TASK 5] PHAN TICH SO SANH ANH GOC vs ANH STEGO')
print('=' * 68)
print('  DELTA={} | Subband={} | {} bits nhung'.format(DELTA, SUBBAND, n_bits))
print()
print('  NANG LUONG TUNG DAI:')
print('  {:>14} {:>16} {:>16} {:>12}'.format('Dai','Cover','Stego','Chenh lech'))
print('  ' + '-' * 60)
for nm, bc, bs in [('LL',LL_c,LL_s),('LH',LH_c,LH_s),
                    ('HL',HL_c,HL_s),('HH',HH_c,HH_s)]:
    ec=np.sum(bc**2); es=np.sum(bs**2)
    mark = ' ← NHUNG' if nm == SUBBAND else ''
    print('  {:>14} {:>16.0f} {:>16.0f} {:>+12.0f}{}'.format(
        nm, ec, es, es-ec, mark))
print()
print('  DANH GIA TINH AN (Steganalysis):')
print('  PSNR                 : {:.4f} dB'.format(psnr))
print('  Histogram diff       : {} pixels'.format(hist_diff))
print('  He so thay doi ({})  : {}/{} ({:.2f}%)'.format(
    SUBBAND, n_changed_band, band_c.size,
    100*n_changed_band/band_c.size))
print()
print('  NHAN XET:')
if psnr > 40:
    print('  - PSNR > 40dB: Anh stego chat luong cao, kho phat hien bang mat thuong')
else:
    print('  - PSNR < 40dB: Co the nhan ra su khac biet neu xem ky')
if hist_diff < 100:
    print('  - Histogram rat tuong dong: kho phat hien bang phan tich thong ke')
else:
    print('  - Histogram co su khac biet: co the phat hien bang steganalysis')
print()
print('  => Ghi vao answer.txt:')
print('     So he so thay doi = {}/{}'.format(n_changed_band, band_c.size))
print('     Histogram diff    = {}'.format(hist_diff))
print('=' * 68)
