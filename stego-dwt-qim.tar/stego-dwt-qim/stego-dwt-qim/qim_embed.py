import numpy as np, json, os
from PIL import Image

# ================================================================
#  TASK 2: NHUNG TIN BANG QIM
#  Cong thuc: c_new = round(c / DELTA) * DELTA + bit * (DELTA/2)
#  bit=0 → c_new la boi so chan cua DELTA
#  bit=1 → c_new = boi so chan + DELTA/2 (dich them nua buoc)
#  Nguoi tach chi can xem (c mod DELTA) < DELTA/2 → bit=0, nguoc lai → bit=1
# ================================================================

SECRET_TEXT = 'PTIT DWT QIM 2026'
DELTA       = 16
SUBBAND     = 'LH'
os.makedirs('results', exist_ok=True)

# Doc 4 dai tu task 1
band_map = {'LH': np.load('results/LH.npy'),
            'HL': np.load('results/HL.npy'),
            'HH': np.load('results/HH.npy')}
band     = band_map[SUBBAND].copy()
h_b, w_b = band.shape

# Chuyen text → bitstream (7-bit ASCII, MSB truoc)
bits = []
for ch in SECRET_TEXT:
    byte = ord(ch)
    for i in range(7, -1, -1):
        bits.append((byte >> i) & 1)

print('=' * 68)
print('  [TASK 2] NHUNG TIN BANG QIM (Quantization Index Modulation)')
print('=' * 68)
print('  Secret text  : "{}"'.format(SECRET_TEXT))
print('  Do dai       : {} ky tu = {} bits'.format(len(SECRET_TEXT), len(bits)))
print('  DELTA (step) : {}'.format(DELTA))
print('  Subband      : {}'.format(SUBBAND))
print('  Capacity dai : {} bits ({} ky tu)'.format(h_b*w_b, h_b*w_b//8))
print()

if len(bits) > h_b * w_b:
    print('  LOI: Tin qua dai, vuot capacity!')
    exit(1)

# Nhung QIM
flat     = band.flatten().copy()
flat_new = flat.copy()

print('  CONG THUC QIM:')
print('  c_new = round(c / {0}) * {0} + bit * {1}'.format(DELTA, DELTA//2))
print()
print('  KIEM TRA 10 HE SO DAU:')
print('  {:>4} {:>12} {:>6} {:>12} {:>10} {:>10}'.format(
    'idx', 'c_goc', 'bit', 'c_new', 'mod_DELTA', 'chenh lech'))
print('  ' + '-' * 58)

for idx, bit in enumerate(bits):
    c          = flat[idx]
    c_new      = round(c / DELTA) * DELTA + bit * (DELTA / 2)
    flat_new[idx] = c_new
    if idx < 10:
        print('  {:>4} {:>12.4f} {:>6} {:>12.4f} {:>10.4f} {:>+10.4f}'.format(
            idx, c, bit, c_new, c_new % DELTA, c_new - c))

print()

# Tinh muc do thay doi
changes    = np.sum(np.abs(flat_new[:len(bits)] - flat[:len(bits)]) > 0.001)
max_change = np.max(np.abs(flat_new[:len(bits)] - flat[:len(bits)]))
mean_change= np.mean(np.abs(flat_new[:len(bits)] - flat[:len(bits)]))

print('  THONG KE THAY DOI HE SO:')
print('  So he so bi thay doi : {}/{} bits nhung'.format(changes, len(bits)))
print('  Chenh lech max       : {:.4f}'.format(max_change))
print('  Chenh lech trung binh: {:.4f}'.format(mean_change))

band_new = flat_new.reshape(h_b, w_b)
np.save('results/band_stego.npy', band_new)
np.save('results/bits_embedded.npy', np.array(bits))

# Luu thong tin nhung
embed_info = {
    'secret_text': SECRET_TEXT,
    'bits'        : bits,
    'n_bits'      : len(bits),
    'DELTA'       : DELTA,
    'SUBBAND'     : SUBBAND,
    'band_shape'  : [h_b, w_b],
}
with open('keys.json', 'w') as f:
    json.dump(embed_info, f, indent=2)

print()
print('  Da luu: results/band_stego.npy')
print('  Da luu: results/bits_embedded.npy')
print('  Da luu: keys.json')
print('=' * 68)
