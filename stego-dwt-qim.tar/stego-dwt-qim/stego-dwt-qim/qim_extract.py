import numpy as np, json, os

# ================================================================
#  TASK 4: TACH TIN BANG QIM
#  Cong thuc giai ma:
#    remainder = c_stego mod DELTA
#    bit = 0 neu remainder < DELTA/2
#    bit = 1 neu remainder >= DELTA/2
# ================================================================

os.makedirs('results', exist_ok=True)
keys        = json.load(open('keys.json'))
SECRET_TEXT = keys['secret_text']
bits_orig   = keys['bits']
DELTA       = keys['DELTA']
SUBBAND     = keys['SUBBAND']
n_bits      = keys['n_bits']

band_stego = np.load('results/band_stego.npy')
flat       = band_stego.flatten()

print('=' * 68)
print('  [TASK 4] TACH TIN BANG QIM')
print('=' * 68)
print('  DELTA   : {}'.format(DELTA))
print('  Subband : {}'.format(SUBBAND))
print('  Can tach: {} bits = {} ky tu'.format(n_bits, n_bits // 8))
print()
print('  CONG THUC GIAI MA:')
print('  remainder = c mod {}'.format(DELTA))
print('  bit = 0 neu remainder < {}  |  bit = 1 neu remainder >= {}'.format(
    DELTA//2, DELTA//2))
print()

# Giai ma QIM
bits_extracted = []
for i in range(n_bits):
    c         = flat[i]
    remainder = c % DELTA
    bit       = 0 if remainder < DELTA / 2 else 1
    bits_extracted.append(bit)

# Kiem tra 10 he so dau
print('  KIEM TRA 10 HE SO DAU:')
print('  {:>4} {:>12} {:>10} {:>10} {:>8} {:>8} {:>6}'.format(
    'idx', 'c_stego', 'mod_DELTA', 'DELTA/2', 'bit_kp', 'bit_goc', 'khop?'))
print('  ' + '-' * 62)
for i in range(10):
    c   = flat[i]
    rem = c % DELTA
    bkp = bits_extracted[i]
    bog = bits_orig[i]
    print('  {:>4} {:>12.4f} {:>10.4f} {:>10} {:>8} {:>8} {:>6}'.format(
        i, c, rem, DELTA//2, bkp, bog, 'OK' if bkp==bog else 'FAIL'))

# Chuyen bit → text
recovered_text = ''
for i in range(0, n_bits, 8):
    byte = 0
    for j in range(8):
        if i + j < n_bits:
            byte = (byte << 1) | bits_extracted[i + j]
    if byte != 0:
        recovered_text += chr(byte)

# BER va ti le khop
n_err  = sum(1 for a, b in zip(bits_orig, bits_extracted) if a != b)
ber    = n_err / n_bits
n_char = min(len(SECRET_TEXT), len(recovered_text))
match  = sum(1 for a, b in zip(SECRET_TEXT, recovered_text) if a == b)
ratio  = match / n_char if n_char > 0 else 0

with open('results/recovered.txt', 'w') as f:
    f.write(recovered_text)

print()
print('  KET QUA TACH TIN:')
print('  Van ban goc  : "{}"'.format(SECRET_TEXT))
print('  Van ban kp   : "{}"'.format(recovered_text))
print('  BER          : {:.6f} ({}/{} bits sai)'.format(ber, n_err, n_bits))
print('  Ti le khop   : {:.2f}%'.format(ratio * 100))
print('  Danh gia     : {}'.format(
    'HOAN CHINH' if ratio == 1.0 else
    'TOT'        if ratio >= 0.9 else 'MOT PHAN'))
print()
print('  Da luu: results/recovered.txt')
print('  => Ghi vao answer.txt: BER = {:.6f}, Ti le khop = {:.2f}%'.format(
    ber, ratio * 100))
print('=' * 68)
