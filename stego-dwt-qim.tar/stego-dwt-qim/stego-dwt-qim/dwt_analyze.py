import pywt, numpy as np, json, math, os
from PIL import Image

# ================================================================
#  TASK 1: BIEN DOI DWT ANH GOC VA CHON DAI NHUNG
#  - Doc anh cover, bien doi DWT Haar 1 muc
#  - Phan tich 4 dai: LL, LH, HL, HH
#  - Tinh nang luong, thong ke tung dai
#  - Chon dai phu hop de nhung tin
# ================================================================

os.makedirs('results', exist_ok=True)

DELTA   = 16
SUBBAND = 'LH'

cover    = np.array(Image.open('cover_image.png').convert('L'), dtype=np.float64)
H, W     = cover.shape

# Bien doi DWT Haar 1 muc
LL, (LH, HL, HH) = pywt.dwt2(cover, 'haar')

# Luu 4 dai de cac task sau dung
np.save('results/LL.npy', LL)
np.save('results/LH.npy', LH)
np.save('results/HL.npy', HL)
np.save('results/HH.npy', HH)

# Tinh thong ke tung dai
total_e = np.sum(LL**2) + np.sum(LH**2) + np.sum(HL**2) + np.sum(HH**2)

def band_stats(name, band):
    e    = np.sum(band**2)
    pct  = 100 * e / total_e
    mn   = band.min()
    mx   = band.max()
    mean = band.mean()
    std  = band.std()
    cap  = band.size          # so he so = so bit co the nhung
    return name, e, pct, mn, mx, mean, std, cap

bands = [
    band_stats('LL (xap xi)', LL),
    band_stats('LH (ngang) ', LH),
    band_stats('HL (doc)   ', HL),
    band_stats('HH (cheo)  ', HH),
]

# Visualize 4 dai
def normalize(b):
    mn, mx = b.min(), b.max()
    if mx == mn: return np.zeros_like(b, dtype=np.uint8)
    return ((b - mn) / (mx - mn) * 255).astype(np.uint8)

h2, w2 = LL.shape
gap    = 4
canvas = np.ones((h2*2+gap*3, w2*2+gap*3), dtype=np.uint8) * 180
canvas[gap:gap+h2,              gap:gap+w2]               = normalize(LL)
canvas[gap:gap+h2,              gap+w2+gap:gap+w2*2+gap]  = normalize(LH)
canvas[gap+h2+gap:gap+h2*2+gap, gap:gap+w2]               = normalize(HL)
canvas[gap+h2+gap:gap+h2*2+gap, gap+w2+gap:gap+w2*2+gap] = normalize(HH)
Image.fromarray(canvas).save('results/dwt_subbands.png')

print('  Anh cover    : {}x{} px  |  Mode: Grayscale'.format(W, H))
print('  Bien doi     : DWT Haar 1 muc')
print('  Kich thuoc   : moi dai {}x{} px'.format(w2, h2))
print()
print('  THONG KE 4 DAI:')
print('  {:>14} {:>14} {:>8} {:>10} {:>10} {:>8} {:>8} {:>10}'.format(
    'Dai', 'Nang luong', '%', 'Min', 'Max', 'Mean', 'Std', 'Capacity'))
print('  ' + '-' * 84)
for nm, e, pct, mn, mx, mean, std, cap in bands:
    print('  {:>14} {:>14.0f} {:>7.2f}% {:>10.2f} {:>10.2f} {:>8.2f} {:>8.2f} {:>8} bit'.format(
        nm, e, pct, mn, mx, mean, std, cap))
print()
print('  CAPACITY NHUNG (DELTA={}):'.format(DELTA))
for nm, e, pct, mn, mx, mean, std, cap in bands[1:]:  # Bo LL
    n_char = cap // 8
    print('  {:>14} : {} bits = {} ky tu ASCII'.format(nm.strip(), cap, n_char))
print()
print('  DAI DUOC CHON DE NHUNG : {} (bien dong trung binh, it anh huong chat luong)'.format(SUBBAND))
print()
print('  Da luu: results/LL.npy, LH.npy, HL.npy, HH.npy')
print('  Da luu: results/dwt_subbands.png')
print('  Mo xem: eog results/dwt_subbands.png')
