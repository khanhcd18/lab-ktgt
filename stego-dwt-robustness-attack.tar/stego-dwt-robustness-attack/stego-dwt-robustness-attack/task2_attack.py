import pywt
import numpy as np
from PIL import Image, ImageFilter
import os
import io
import math
from scipy.ndimage import rotate

IMAGE_PATH     = 'input_image.png'
WATERMARK_PATH = 'watermark.png'
OUTPUT_DIR     = 'results'
STEGO_HAAR     = os.path.join(OUTPUT_DIR, 'stego_haar.png')
STEGO_DAUB     = os.path.join(OUTPUT_DIR, 'stego_db4.png')
STRENGTH       = 0.15

os.makedirs(OUTPUT_DIR, exist_ok=True)

def extract_wm(stego_arr, orig_arr, wavelet='haar'):
    _, (LH_s, _, _) = pywt.dwt2(stego_arr.astype(np.float64), wavelet)
    _, (LH_o, _, _) = pywt.dwt2(orig_arr.astype(np.float64), wavelet)
    lh_max = np.abs(LH_o).max() or 1.0
    wm = np.clip((LH_s - LH_o) / (lh_max * STRENGTH) * 255, 0, 255).astype(np.uint8)
    return wm

def calc_ber(wm_orig, wm_extracted):
    orig_bin = (np.array(wm_orig, dtype=np.float32) > 128).astype(np.uint8)
    extr_bin = (wm_extracted > 128).astype(np.uint8)
    if extr_bin.shape != orig_bin.shape:
        extr_img = Image.fromarray(extr_bin * 255).resize(
            (orig_bin.shape[1], orig_bin.shape[0]), Image.Resampling.NEAREST)
        extr_bin = (np.array(extr_img) > 128).astype(np.uint8)
    return np.mean(orig_bin != extr_bin)

def attack_jpeg(img_arr, quality=50):
    img = Image.fromarray(img_arr)
    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=quality)
    buf.seek(0)
    return np.array(Image.open(buf).convert('L'))

def attack_gaussian(img_arr, sigma=2):
    from scipy.ndimage import gaussian_filter
    noisy = img_arr.astype(np.float64) + np.random.normal(0, sigma, img_arr.shape)
    return np.clip(noisy, 0, 255).astype(np.uint8)

def attack_median(img_arr, size=3):
    img = Image.fromarray(img_arr)
    filtered = img.filter(ImageFilter.MedianFilter(size=size))
    return np.array(filtered)

def attack_rotation(img_arr, angle=5):
    rotated = rotate(img_arr.astype(np.float64), angle, reshape=False, cval=0)
    return np.clip(rotated, 0, 255).astype(np.uint8)

attacks = [
    ('JPEG recompression (q=50)', attack_jpeg),
    ('Gaussian noise (sigma=2)',  attack_gaussian),
    ('Median filter (3x3)',       attack_median),
    ('Rotation (5 deg)',          attack_rotation),
]

orig_arr = np.array(Image.open(IMAGE_PATH).convert('L'))
wm_img   = Image.open(WATERMARK_PATH).convert('L')

print("=" * 60)
print("KIEM TRA DO BEN WATERMARK TRUOC TAN CONG")
print("=" * 60)

for wavelet, stego_path in [('haar', STEGO_HAAR), ('db4', STEGO_DAUB)]:
    print("\n--- Wavelet: {} ---".format(wavelet))
    stego_arr = np.array(Image.open(stego_path).convert('L'))

    for atk_name, atk_fn in attacks:
        attacked = atk_fn(stego_arr)
        wm_ext   = extract_wm(attacked, orig_arr, wavelet=wavelet)

        # Luu anh tan cong vao results/
        tag = atk_name.split()[0].lower()
        out_path = os.path.join(OUTPUT_DIR, 'attacked_{}_{}.png'.format(wavelet, tag))
        Image.fromarray(attacked).save(out_path)

        ber = calc_ber(wm_img, wm_ext)
        print("    {:35s} BER = {:.4f}".format(atk_name, ber))

print()
print("    Mo anh tan cong : eog results/")
print("    Tiep theo       : nano answer.txt")
