import pywt
import numpy as np
from PIL import Image, ImageFilter
import os
import io
import math
from scipy.ndimage import rotate

IMAGE_PATH     = 'input_image.png'
WATERMARK_PATH = 'watermark.png'
OUTPUT_DIR     = 'results'
STEGO_HAAR     = os.path.join(OUTPUT_DIR, 'stego_haar.png')
STEGO_DAUB     = os.path.join(OUTPUT_DIR, 'stego_db4.png')
STRENGTH       = 0.15

os.makedirs(OUTPUT_DIR, exist_ok=True)


# --- Kiem tra file stego da ton tai chua ---
if not os.path.exists(STEGO_HAAR) or not os.path.exists(STEGO_DAUB):
    print("[LOI] Chua co file stego trong results/")
    print("      Hay chay task1_embed.py truoc: python3 task1_embed.py")
    exit(1)


def extract_wm(stego_arr, orig_arr, wavelet='haar'):
    """
    Trich xuat watermark tu dai LH.
    Chi trich tu LH vi nhung cung chi vao LH o task1.
    Cong thuc: wm = (LH_stego - LH_orig) / (max(|LH_orig|) x strength)
    """
    _, (LH_s, _, _) = pywt.dwt2(stego_arr.astype(np.float64), wavelet)
    _, (LH_o, _, _) = pywt.dwt2(orig_arr.astype(np.float64),  wavelet)

    lh_max = np.abs(LH_o).max()
    if lh_max == 0:
        lh_max = 1.0

    wm = (LH_s - LH_o) / (lh_max * STRENGTH) * 255
    wm = np.clip(wm, 0, 255).astype(np.uint8)
    return wm


def calc_ber(wm_orig_img, wm_extracted_arr):
    """
    Tinh BER (Bit Error Rate) giua watermark goc va watermark trich xuat.
    BER = so bit sai / tong so bit
    BER = 0 : watermark con nguyen ven
    BER = 1 : watermark bi pha huy hoan toan
    """
    orig_bin = (np.array(wm_orig_img, dtype=np.float32) > 128).astype(np.uint8)
    extr_bin = (wm_extracted_arr > 128).astype(np.uint8)

    # Neu kich thuoc khac nhau thi resize ve bang nhau
    if extr_bin.shape != orig_bin.shape:
        extr_img = Image.fromarray(extr_bin * 255).resize(
            (orig_bin.shape[1], orig_bin.shape[0]),
            Image.Resampling.NEAREST
        )
        extr_bin = (np.array(extr_img) > 128).astype(np.uint8)

    return float(np.mean(orig_bin != extr_bin))


# --- 4 ham tan cong ---

def attack_jpeg(img_arr, quality=50):
    """
    Nen lai anh bang JPEG chat luong thap.
    JPEG la nen mat mat, loai bo thanh phan tan so cao
    lam suy giam watermark o dai LH.
    """
    img = Image.fromarray(img_arr)
    buf = io.BytesIO()
    img.save(buf, format='JPEG', quality=quality)
    buf.seek(0)
    return np.array(Image.open(buf).convert('L'))


def attack_gaussian(img_arr, sigma=2):
    """
    Them nhieu Gaussian vao anh.
    Nhieu ngau nhien lam thay doi gia tri pixel,
    keo theo nhieu loan cac he so DWT khi trich xuat.
    """
    noise  = np.random.normal(0, sigma, img_arr.shape)
    noisy  = img_arr.astype(np.float64) + noise
    return np.clip(noisy, 0, 255).astype(np.uint8)


def attack_median(img_arr, size=3):
    """
    Loc trung vi voi cua so 3x3.
    Thay the moi pixel bang gia tri trung vi cua vung lan can,
    xoa bo cac thay doi nho ma watermark tao ra.
    """
    img      = Image.fromarray(img_arr)
    filtered = img.filter(ImageFilter.MedianFilter(size=size))
    return np.array(filtered)


def attack_rotation(img_arr, angle=5):
    """
    Xoay anh mot goc 5 do.
    Lam lech vi tri khong gian cua pixel, pha vo su can chinh
    giua he so DWT cua anh bi tan cong va anh goc khi trich xuat.
    """
    rotated = rotate(img_arr.astype(np.float64), angle,
                     reshape=False, cval=0)
    return np.clip(rotated, 0, 255).astype(np.uint8)


# --- Danh sach tan cong ---
attacks = [
    ('JPEG recompression (q=50)', attack_jpeg),
    ('Gaussian noise (sigma=2)',  attack_gaussian),
    ('Median filter (3x3)',       attack_median),
    ('Rotation (5 deg)',          attack_rotation),
]

# --- Doc du lieu goc ---
orig_arr = np.array(Image.open(IMAGE_PATH).convert('L'))
wm_img   = Image.open(WATERMARK_PATH).convert('L')

# --- Chay tat ca tan cong ---
print("=" * 60)
print("KIEM TRA DO BEN WATERMARK TRUOC TAN CONG")
print("=" * 60)

ber_results = {}

for wavelet, stego_path in [('haar', STEGO_HAAR), ('db4', STEGO_DAUB)]:
    print("\n--- Wavelet: {} ---".format(wavelet))
    stego_arr = np.array(Image.open(stego_path).convert('L'))
    ber_results[wavelet] = {}

    for atk_name, atk_fn in attacks:
        # Thuc hien tan cong
        attacked = atk_fn(stego_arr)

        # Luu anh da bi tan cong
        tag      = atk_name.split()[0].lower()
        out_path = os.path.join(OUTPUT_DIR, 'attacked_{}_{}.png'.format(wavelet, tag))
        Image.fromarray(attacked).save(out_path)

        # Trich xuat watermark va tinh BER
        wm_ext = extract_wm(attacked, orig_arr, wavelet=wavelet)
        ber    = calc_ber(wm_img, wm_ext)

        ber_results[wavelet][atk_name] = ber

        # Danh gia muc do
        if ber < 0.1:
            level = "ben vung"
        elif ber < 0.3:
            level = "bi anh huong nhe"
        elif ber < 0.5:
            level = "bi anh huong nhieu"
        else:
            level = "bi pha huy"

        print("    {:<35s} BER = {:.4f}  ({})".format(atk_name, ber, level))

# --- In ket qua tong hop ---
print()
print("=" * 60)
print("KET QUA TONG HOP")
print("=" * 60)

for wavelet in ['haar', 'db4']:
    bers  = ber_results[wavelet]
    avg   = sum(bers.values()) / len(bers)
    worst = max(bers, key=bers.get)
    print("  Wavelet {:5s} | BER trung binh: {:.4f} | Tan cong nguy hiem nhat: {}".format(
        wavelet, avg, worst.split('(')[0].strip()
    ))

haar_avg = sum(ber_results['haar'].values()) / len(ber_results['haar'])
db4_avg  = sum(ber_results['db4'].values())  / len(ber_results['db4'])

print()
if db4_avg < haar_avg:
    print("  => Daubechies (db4) ben hon truoc tan cong (BER trung binh thap hon)")
elif haar_avg < db4_avg:
    print("  => Haar ben hon truoc tan cong (BER trung binh thap hon)")
else:
    print("  => Hai wavelet co do ben tuong duong")

print()
print("    Mo anh tan cong : eog results/")
