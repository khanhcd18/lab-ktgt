import pywt
import numpy as np
from PIL import Image
import os
import math

IMAGE_PATH     = 'input_image.png'
WATERMARK_PATH = 'watermark.png'
OUTPUT_DIR     = 'results'
OUTPUT_HAAR    = os.path.join(OUTPUT_DIR, 'stego_haar.png')
OUTPUT_DAUB    = os.path.join(OUTPUT_DIR, 'stego_db4.png')
STRENGTH       = 0.15

os.makedirs(OUTPUT_DIR, exist_ok=True)


def calc_psnr(orig_arr, stego_arr):
    mse = np.mean((orig_arr.astype(np.float64) - stego_arr.astype(np.float64)) ** 2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(255.0 / math.sqrt(mse))


def embed(image_path, wm_path, output_path, wavelet='haar', strength=0.15):
    # Kiem tra file dau vao
    if not os.path.exists(image_path):
        print("[LOI] Khong tim thay file: {}".format(image_path))
        exit(1)
    if not os.path.exists(wm_path):
        print("[LOI] Khong tim thay file: {}".format(wm_path))
        exit(1)

    img = Image.open(image_path).convert('L')
    arr = np.array(img, dtype=np.float64)
    wm  = Image.open(wm_path).convert('L')

    # Phan ra anh thanh 4 dai tan bang DWT
    coeffs = pywt.dwt2(arr, wavelet)
    LL, (LH, HL, HH) = coeffs

    # Resize watermark ve dung kich thuoc dai LH
    wm_resized = wm.resize((LH.shape[1], LH.shape[0]), Image.Resampling.LANCZOS)
    wm_arr     = np.array(wm_resized, dtype=np.float64)

    # Nhi phan hoa watermark: pixel > 128 thi = 1, nguoc lai = 0
    wm_bin = (wm_arr > 128).astype(np.float64)

    # Nhung watermark chi vao dai LH
    # Cong thuc: LH_moi = LH_cu + strength x watermark_binary x max(|LH|)
    LH_w = LH + strength * wm_bin * np.abs(LH).max()

    # Tai tao anh bang IDWT, giu nguyen HL va HH
    img_out = pywt.idwt2((LL, (LH_w, HL, HH)), wavelet)

    # Crop ve dung kich thuoc anh goc (db4 co the tao anh lon hon 1 pixel)
    img_out = img_out[:arr.shape[0], :arr.shape[1]]
    img_out = np.clip(img_out, 0, 255).astype(np.uint8)

    # Tinh PSNR de danh gia chat luong anh sau nhung
    psnr = calc_psnr(arr, img_out.astype(np.float64))

    Image.fromarray(img_out).save(output_path)
    print("    Da luu : {}".format(output_path))
    print("    PSNR   : {:.4f} dB  ({})".format(
        psnr,
        "chat luong tot" if psnr >= 35 else "chat luong trung binh"
    ))


print("=" * 55)
print("NHUNG WATERMARK BANG DWT")
print("=" * 55)

print("\n[1] Haar wavelet (haar)")
embed(IMAGE_PATH, WATERMARK_PATH, OUTPUT_HAAR, wavelet='haar', strength=STRENGTH)

print("\n[2] Daubechies wavelet (db4)")
embed(IMAGE_PATH, WATERMARK_PATH, OUTPUT_DAUB, wavelet='db4', strength=STRENGTH)

print()
print("=" * 55)
print("    Mo anh Haar : eog results/stego_haar.png")
print("    Mo anh db4  : eog results/stego_db4.png")
