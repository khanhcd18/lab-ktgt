import pywt
import numpy as np
from PIL import Image
import os

IMAGE_PATH     = 'input_image.png'
WATERMARK_PATH = 'watermark.png'
OUTPUT_DIR     = 'results'
OUTPUT_HAAR    = os.path.join(OUTPUT_DIR, 'stego_haar.png')
OUTPUT_DAUB    = os.path.join(OUTPUT_DIR, 'stego_db4.png')
STRENGTH       = 0.15

os.makedirs(OUTPUT_DIR, exist_ok=True)

def embed(image_path, wm_path, output_path, wavelet='haar', strength=0.15):
    img = Image.open(image_path).convert('L')
    arr = np.array(img, dtype=np.float64)
    wm  = Image.open(wm_path).convert('L')

    coeffs = pywt.dwt2(arr, wavelet)
    LL, (LH, HL, HH) = coeffs

    wm_lh = np.array(wm.resize((LH.shape[1], LH.shape[0]), Image.Resampling.LANCZOS), dtype=np.float64)
    wm_hl = np.array(wm.resize((HL.shape[1], HL.shape[0]), Image.Resampling.LANCZOS), dtype=np.float64)
    wm_bin_lh = (wm_lh > 128).astype(np.float64)
    wm_bin_hl = (wm_hl > 128).astype(np.float64)

    LH_w = LH + strength * wm_bin_lh * np.abs(LH).max()
    HL_w = HL + strength * wm_bin_hl * np.abs(HL).max()

    img_out = pywt.idwt2((LL, (LH_w, HL_w, HH)), wavelet)
    img_out = img_out[:arr.shape[0], :arr.shape[1]]
    img_out = np.clip(img_out, 0, 255).astype(np.uint8)
    Image.fromarray(img_out).save(output_path)
    print("    Da luu: {}".format(output_path))

print("=" * 55)
print("[1] Nhung watermark bang Haar wavelet")
embed(IMAGE_PATH, WATERMARK_PATH, OUTPUT_HAAR, wavelet='haar', strength=STRENGTH)
print("[2] Nhung watermark bang Daubechies (db4)")
embed(IMAGE_PATH, WATERMARK_PATH, OUTPUT_DAUB, wavelet='db4', strength=STRENGTH)
print()
print("    Tiep theo: python3 task2_attack.py")
