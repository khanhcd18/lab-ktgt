import pywt
import numpy as np
from PIL import Image
import os

IMAGE_CLEAN  = 'input_image.png'
IMAGE_STEGO  = 'stego_image.png'
OUTPUT_DIR   = 'results'
os.makedirs(OUTPUT_DIR, exist_ok=True)

def ws_detect(image_path):
    img = Image.open(image_path).convert('L')
    arr = np.array(img, dtype=np.float64)
    coeffs = pywt.dwt2(arr, 'haar')
    LL, (LH, HL, HH) = coeffs
    # WS: tinh tuong quan giua he so va lang gieng
    shifted = np.roll(LH, 1, axis=1)
    ws_score = np.mean(np.abs(LH - shifted))
    return ws_score

print("=" * 55)
print("[1] Phan tich WS detector")
print("=" * 55)

score_clean = ws_detect(IMAGE_CLEAN)
print("    Anh sach  - WS score: {:.6f}".format(score_clean))

score_stego = ws_detect(IMAGE_STEGO)
print("    Anh stego - WS score: {:.6f}".format(score_stego))

print()
diff = abs(score_stego - score_clean)
print("    Chenh lech WS score : {:.6f}".format(diff))

if diff > 0.5:
    print("    => WS detector: ANH STEGO DA BI PHAT HIEN (detected)")
else:
    print("    => WS detector: KHONG PHAT HIEN DUOC (not detected)")

print()
print("    Tiep theo: nano answer.txt")
