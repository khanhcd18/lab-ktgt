import pywt
import numpy as np
from PIL import Image
import os

IMAGE_CLEAN  = 'input_image.png'
IMAGE_STEGO  = 'stego_image.png'
OUTPUT_DIR   = 'results'
os.makedirs(OUTPUT_DIR, exist_ok=True)

def ws_detect(image_path):
    img = Image.open(image_path).convert('L')
    arr = np.array(img, dtype=np.float64)
    coeffs = pywt.dwt2(arr, 'haar')
    LL, (LH, HL, HH) = coeffs
    shifted = np.roll(LH, 1, axis=1)
    ws_score = np.mean(np.abs(LH - shifted))
    return ws_score, img

print("=" * 55)
print("[1] Phan tich WS detector")
print("=" * 55)

score_clean, img_clean = ws_detect(IMAGE_CLEAN)
print("    Anh sach  - WS score: {:.6f}".format(score_clean))

score_stego, img_stego = ws_detect(IMAGE_STEGO)
print("    Anh stego - WS score: {:.6f}".format(score_stego))

print()
diff = abs(score_stego - score_clean)
print("    Chenh lech WS score : {:.6f}".format(diff))

if diff > 0.05:
    print("    => WS detector: ANH STEGO DA BI PHAT HIEN (detected)")
else:
    print("    => WS detector: KHONG PHAT HIEN DUOC (not detected)")

# Luu anh ket qua vao results/
arr_clean = np.array(img_clean)
arr_stego = np.array(img_stego)

gap = 10
h, w = arr_clean.shape
canvas = np.ones((h, w * 2 + gap), dtype=np.uint8) * 128
canvas[:, :w] = arr_clean
canvas[:, w + gap:] = arr_stego
Image.fromarray(canvas).save(os.path.join(OUTPUT_DIR, 'compare_clean_vs_stego.png'))

diff_arr = np.abs(arr_clean.astype(np.float64) - arr_stego.astype(np.float64))
diff_norm = (diff_arr / diff_arr.max() * 255).astype(np.uint8) if diff_arr.max() > 0 else diff_arr.astype(np.uint8)
Image.fromarray(diff_norm).save(os.path.join(OUTPUT_DIR, 'difference_map.png'))

print()
print("    Da luu: results/compare_clean_vs_stego.png")
print("    Da luu: results/difference_map.png")
print()
print("    Mo anh so sanh : eog results/compare_clean_vs_stego.png")
print("    Mo ban do diff : eog results/difference_map.png")
print("    Tiep theo      : nano answer.txt")
