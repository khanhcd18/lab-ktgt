import pywt
import numpy as np
from PIL import Image
import os

IMAGE_PATH     = 'input_image.png'
WATERMARK_PATH = 'watermark.png'
OUTPUT_STEGO   = 'stego_image.png'

img = Image.open(IMAGE_PATH).convert('L')
arr = np.array(img, dtype=np.float64)
wm  = Image.open(WATERMARK_PATH).convert('L')

coeffs = pywt.dwt2(arr, 'haar')
LL, (LH, HL, HH) = coeffs

wm_r = wm.resize((LH.shape[1], LH.shape[0]), Image.Resampling.LANCZOS)
wm_b = (np.array(wm_r, dtype=np.float64) > 128).astype(np.float64)

LH_s = LH + 0.1 * wm_b * np.abs(LH).max()
HL_s = HL + 0.1 * wm_b * np.abs(HL).max()

img_stego = pywt.idwt2((LL, (LH_s, HL_s, HH)), 'haar')
img_stego = img_stego[:arr.shape[0], :arr.shape[1]]
img_stego = np.clip(img_stego, 0, 255).astype(np.uint8)
Image.fromarray(img_stego).save(OUTPUT_STEGO)

print("[+] Da tao anh stego: {}".format(OUTPUT_STEGO))
print("    Tiep theo: python3 task1_detect.py")
