import os
import json

KEY_FILE = 'aes_key.json'

def generate_key():
    key = os.urandom(16)
    iv  = os.urandom(16)
    return {
        'algorithm' : 'AES-128-CBC',
        'key_hex'   : key.hex(),
        'iv_hex'    : iv.hex(),
        'key_bits'  : 128
    }

def print_key_info(data):
    key = data['key_hex']
    iv  = data['iv_hex']
    print("=" * 60)
    print("  THUAT TOAN : {}".format(data['algorithm']))
    print("  DO DAI KHOA: {} bit = {} byte".format(data['key_bits'], data['key_bits'] // 8))
    print()
    print("  KEY (hex)  : {}".format(key))
    print("  KEY (bin)  : {}...".format(
        bin(int(key[:4], 16))[2:].zfill(16)))
    print()
    print("  IV  (hex)  : {}".format(iv))
    print()
    print("  [+] Da luu vao: {}".format(KEY_FILE))
    print("=" * 60)

data = generate_key()

with open(KEY_FILE, 'w') as f:
    json.dump(data, f, indent=2)

print_key_info(data)
