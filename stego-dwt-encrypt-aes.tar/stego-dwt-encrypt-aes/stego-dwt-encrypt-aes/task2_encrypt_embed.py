import pywt
import numpy as np
from PIL import Image
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad
import os
import json
import math
import struct

KEY_FILE    = 'aes_key.json'
COVER_PATH  = 'cover_image.png'
SECRET_PATH = 'secret_image.png'
OUTPUT_DIR  = 'results'
STEGO_PATH  = os.path.join(OUTPUT_DIR, 'stego_image.png')
META_FILE   = os.path.join(OUTPUT_DIR, 'embed_meta.json')

os.makedirs(OUTPUT_DIR, exist_ok=True)

def calculate_psnr(a, b):
    a = a.astype(np.float64)
    b = b.astype(np.float64)
    h = min(a.shape[0], b.shape[0])
    w = min(a.shape[1], b.shape[1])
    mse = np.mean((a[:h,:w] - b[:h,:w]) ** 2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(255.0 / math.sqrt(mse))

def image_to_bytes(path):
    img = Image.open(path).convert('L')
    arr = np.array(img, dtype=np.uint8)
    h, w = arr.shape
    return struct.pack('>HH', h, w) + arr.tobytes(), h, w

def encrypt_aes(data, key_hex, iv_hex):
    key    = bytes.fromhex(key_hex)
    iv     = bytes.fromhex(iv_hex)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    ct     = cipher.encrypt(pad(data, AES.block_size))
    return struct.pack('>I', len(ct)) + ct

def bytes_to_bits(data):
    bits = []
    for byte in data:
        for pos in range(7, -1, -1):
            bits.append((byte >> pos) & 1)
    return bits

def get_dwt_mask(shape):
    """
    Dung DWT de tim vi tri nang luong thap (LH+HL)
    tra ve danh sach (row, col) theo thu tu nang luong tang dan
    -> nhung vao vung it anh huong nhat den mat nguoi
    """
    dummy  = np.zeros(shape, dtype=np.float64)
    coeffs = pywt.dwt2(dummy + 1, 'haar')
    LL, (LH, HL, HH) = coeffs
    h2, w2 = LH.shape

    # Vung LH: hang 0..h2-1, cot w2..2*w2-1
    # Vung HL: hang h2..2*h2-1, cot 0..w2-1
    positions = []
    for r in range(h2):
        for c in range(w2):
            positions.append((r, w2 + c))        # vung LH
    for r in range(h2):
        for c in range(w2):
            positions.append((h2 + r, c))        # vung HL
    return positions

# --- DOC DU LIEU ---
with open(KEY_FILE, 'r') as f:
    kd = json.load(f)

secret_bytes, s_h, s_w = image_to_bytes(SECRET_PATH)
cover_img = Image.open(COVER_PATH).convert('L')
cover_arr = np.array(cover_img, dtype=np.uint8).copy()

# --- MA HOA AES ---
blob = encrypt_aes(secret_bytes, kd['key_hex'], kd['iv_hex'])
bits = bytes_to_bits(blob)

# --- LAY DANH SACH VI TRI NHUNG (theo DWT mask) ---
positions = get_dwt_mask(cover_arr.shape)

if len(bits) > len(positions):
    raise ValueError(
        "Ciphertext ({} bit) vuot capacity ({} vi tri)".format(
            len(bits), len(positions)))

# --- NHUNG LSB VAO PIXEL TAI VI TRI DWT MASK ---
stego_arr = cover_arr.copy()
for i, bit in enumerate(bits):
    r, c         = positions[i]
    stego_arr[r, c] = (int(stego_arr[r, c]) & ~1) | bit

psnr = calculate_psnr(cover_arr, stego_arr)
Image.fromarray(stego_arr).save(STEGO_PATH)

# --- LUU METADATA ---
meta = {
    'blob_bytes' : len(blob),
    'n_bits'     : len(bits),
    'secret_h'   : s_h,
    'secret_w'   : s_w,
    'cover_h'    : cover_arr.shape[0],
    'cover_w'    : cover_arr.shape[1],
    'psnr'       : round(psnr, 4)
}
with open(META_FILE, 'w') as f:
    json.dump(meta, f, indent=2)

half = len(bits) // 2
print("=" * 60)
print("  [1] ANH BI MAT: {} x {} px | {} bytes raw".format(s_w, s_h, len(secret_bytes)))
print()
print("  [2] MA HOA AES-128-CBC")
print("      Blob bytes: {}".format(len(blob)))
print("      Tong bits : {}".format(len(bits)))
print()
print("  [3] NHUNG VAO PIXEL (vi tri do DWT LH+HL xac dinh)")
print("      Vi tri LH  : {} pixel".format(half))
print("      Vi tri HL  : {} pixel".format(len(bits) - half))
print("      Total cap  : {} vi tri".format(len(positions)))
print("      Su dung    : {:.1f}% capacity".format(
    100 * len(bits) / len(positions)))
print()
print("  [4] PSNR: {:.4f} dB  ({})".format(
    psnr, "TOT" if psnr >= 30 else "TRUNG BINH"))
print("      Da luu: {}".format(STEGO_PATH))
print("=" * 60)
