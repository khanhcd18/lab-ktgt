import pywt
import numpy as np
from PIL import Image
from Crypto.Cipher import AES
from Crypto.Util.Padding import unpad
import os
import json
import math
import struct

KEY_FILE    = 'aes_key.json'
META_FILE   = os.path.join('results', 'embed_meta.json')
STEGO_PATH  = os.path.join('results', 'stego_image.png')
SECRET_PATH = 'secret_image.png'
OUTPUT_DIR  = 'results'
RECOVERED   = os.path.join(OUTPUT_DIR, 'recovered_secret.png')
DIFF_MAP    = os.path.join(OUTPUT_DIR, 'diff_map.png')
WRONG_OUT   = os.path.join(OUTPUT_DIR, 'wrong_key_attempt.png')

def get_dwt_mask(shape):
    dummy  = np.zeros(shape, dtype=np.float64)
    coeffs = pywt.dwt2(dummy + 1, 'haar')
    LL, (LH, HL, HH) = coeffs
    h2, w2 = LH.shape
    positions = []
    for r in range(h2):
        for c in range(w2):
            positions.append((r, w2 + c))
    for r in range(h2):
        for c in range(w2):
            positions.append((h2 + r, c))
    return positions

def extract_lsb(arr, positions, n_bits):
    return [int(arr[r, c]) & 1 for r, c in positions[:n_bits]]

def bits_to_bytes(bits):
    result = bytearray()
    for i in range(0, len(bits), 8):
        byte = 0
        for j in range(8):
            if i + j < len(bits):
                byte = (byte << 1) | bits[i + j]
        result.append(byte)
    return bytes(result)

def decrypt_aes(blob, key_hex, iv_hex):
    key    = bytes.fromhex(key_hex)
    iv     = bytes.fromhex(iv_hex)
    length = struct.unpack('>I', blob[:4])[0]
    ct     = blob[4:4 + length]
    cipher = AES.new(key, AES.MODE_CBC, iv)
    return unpad(cipher.decrypt(ct), AES.block_size)

def bytes_to_image(data):
    h, w = struct.unpack('>HH', data[:4])
    arr  = np.frombuffer(data[4:4+h*w], dtype=np.uint8).reshape(h, w)
    return Image.fromarray(arr.copy())

def calculate_psnr(a, b):
    a = a.astype(np.float64)
    b = b.astype(np.float64)
    h = min(a.shape[0], b.shape[0])
    w = min(a.shape[1], b.shape[1])
    mse = np.mean((a[:h,:w] - b[:h,:w]) ** 2)
    if mse == 0:
        return float('inf')
    return 20 * math.log10(255.0 / math.sqrt(mse))

# --- DOC ---
with open(KEY_FILE, 'r') as f:
    kd = json.load(f)
with open(META_FILE, 'r') as f:
    meta = json.load(f)

key_hex  = kd['key_hex']
iv_hex   = kd['iv_hex']
n_bits   = meta['n_bits']
blob_len = meta['blob_bytes']
shape    = (meta['cover_h'], meta['cover_w'])

stego_arr = np.array(Image.open(STEGO_PATH).convert('L'), dtype=np.uint8)
positions = get_dwt_mask(shape)

# --- TRICH XUAT ---
bits = extract_lsb(stego_arr, positions, n_bits)
blob = bits_to_bytes(bits)[:blob_len]

# --- GIAI MA DUNG KHOA ---
recovered_ok = False
psnr_rec     = 0.0
try:
    pt  = decrypt_aes(blob, key_hex, iv_hex)
    img = bytes_to_image(pt)
    img.save(RECOVERED)

    orig = np.array(Image.open(SECRET_PATH).convert('L'), dtype=np.uint8)
    recv = np.array(img, dtype=np.uint8)
    psnr_rec = calculate_psnr(orig, recv)

    diff = np.abs(orig.astype(np.float64) - recv.astype(np.float64))
    dn   = (diff / diff.max() * 255).astype(np.uint8) if diff.max() > 0 \
           else np.zeros_like(orig)
    Image.fromarray(dn).save(DIFF_MAP)
    recovered_ok = True
except Exception as e:
    err_msg = str(e)

# --- GIAI MA KHOA SAI ---
wk = bytes.fromhex(key_hex)
wk = bytes([wk[0] ^ 0xFF]) + wk[1:]
try:
    wp = decrypt_aes(blob, wk.hex(), iv_hex)
    bytes_to_image(wp).save(WRONG_OUT)
    wrong_msg = "du lieu rac, khong the doc duoc anh"
except Exception:
    noise = np.random.randint(0, 256,
            (meta['secret_h'], meta['secret_w']), dtype=np.uint8)
    Image.fromarray(noise).save(WRONG_OUT)
    wrong_msg = "padding error - giai ma that bai hoan toan"

# --- IN KET QUA ---
print("=" * 60)
print("  [1] TRICH XUAT LSB TAI VI TRI DWT MASK")
print("      Tong bit trich xuat: {}".format(n_bits))
print()
print("  [2] GIAI MA AES-128-CBC (KHOA DUNG)")
if recovered_ok:
    print("      Trang thai : THANH CONG (decrypted successfully)")
    print("      PSNR phuc hoi vs goc: {:.4f} dB".format(psnr_rec))
    print("      Da luu     : {}".format(RECOVERED))
    print("      Diff map   : {}".format(DIFF_MAP))
else:
    print("      Trang thai : THAT BAI - {}".format(err_msg))
print()
print("  [3] GIAI MA AES-128-CBC (KHOA SAI - 1 byte bi flip)")
print("      Ket qua: {}".format(wrong_msg))
print("      Da luu : {}".format(WRONG_OUT))
print("=" * 60)
