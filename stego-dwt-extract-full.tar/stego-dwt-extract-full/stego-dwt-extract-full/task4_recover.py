import numpy as np, json, os

SA_recovered=np.load('results/SA_recovered.npy')
keys=json.load(open('keys.json'))
SECRET_TEXT=keys['secret_text']
os.makedirs('results',exist_ok=True)

def matrix_to_text(sa):
    """Chuyen ma tran ASCII → chuoi van ban, bo ky tu null (=0)."""
    chars=[]
    for row in sa:
        for val in row:
            code=int(round(val)); code=max(0,min(127,code))
            if code!=0: chars.append(chr(code))
    return ''.join(chars)


def compare_texts(orig,rec):
    """Ti le ky tu khop chinh xac."""
    n=min(len(orig),len(rec))
    return sum(1 for a,b in zip(orig,rec) if a==b)/n if n>0 else 0.0
    # [CODE MAU - bo dau # de chay]
    # n=min(len(orig),len(rec))
    # return sum(1 for a,b in zip(orig,rec) if a==b)/n if n>0 else 0.0

recovered_text=matrix_to_text(SA_recovered)
match_ratio   =compare_texts(SECRET_TEXT,recovered_text)
with open('results/recovered_secret.txt','w') as f: f.write(recovered_text)

flat=SA_recovered.flatten()
print("="*65)
print("  [TASK 4] KHOI PHUC VAN BAN BI MAT")
print("="*65)
print("  Van ban goc: '{}'".format(SECRET_TEXT))
print("  Van ban kp : '{}'".format(recovered_text))
print("  Do dai: goc={} | kp={}".format(len(SECRET_TEXT),len(recovered_text)))
print("  Ti le khop: {:.2f}%".format(match_ratio*100))
print()
verdict="HOAN CHINH" if match_ratio==1.0 else "TOT" if match_ratio>=0.9 else "MOT PHAN"
print("  => KHOI PHUC {} ({:.1f}% khop)".format(verdict,match_ratio*100))
print()
print("  PHAN TICH TUNG KY TU (hien thi FAIL):")
print("  {:>4} {:>6} {:>6} {:>8} {:>6} {:>10}".format("i","Goc","KP","ASCII_KP","Khop","raw_SA"))
print("  "+"-"*44)
padded=recovered_text+' '*(len(SECRET_TEXT)-len(recovered_text))
for i,(a,b) in enumerate(zip(SECRET_TEXT,padded)):
    mark='OK' if a==b else 'FAIL'
    raw=flat[i] if i<len(flat) else 0
    if mark=='FAIL' or i<6:
        print("  {:>4} {:>6} {:>6} {:>8} {:>6} {:>10.3f}".format(
            i,repr(a),repr(b),ord(b) if b!=' ' or i<len(recovered_text) else 0,mark,raw))
print()
print("  Da luu: results/recovered_secret.txt")
print("="*65)
