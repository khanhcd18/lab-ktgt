import pywt, numpy as np
from PIL import Image
import os, json

os.makedirs('results', exist_ok=True)
keys       = json.load(open('keys.json'))
BLOCK_SIZE = keys['block_size']

IA_s = np.load('results/IA_stego.npy')
IH_s = np.load('results/IH_stego.npy')
IV_s = np.load('results/IV_stego.npy')
ID_s = np.load('results/ID_stego.npy')

# Doc anh goc de tinh chenh lech nang luong
orig_arr          = np.array(Image.open('original_image.png').convert('L'), dtype=np.float64)
LL_o,(LH_o,HL_o,HH_o) = pywt.dwt2(orig_arr, 'haar')
H, W              = orig_arr.shape
h2, w2            = IA_s.shape

total_s = np.sum(IA_s**2)+np.sum(IH_s**2)+np.sum(IV_s**2)+np.sum(ID_s**2)

# Visualize 4 dai
def normalize(b):
    mn,mx=b.min(),b.max()
    return np.zeros_like(b,dtype=np.uint8) if mx==mn else ((b-mn)/(mx-mn)*255).astype(np.uint8)

gap=4
canvas=np.ones((h2*2+gap*3, w2*2+gap*3), dtype=np.uint8)*180
canvas[gap:gap+h2,              gap:gap+w2]               = normalize(IA_s)
canvas[gap:gap+h2,              gap+w2+gap:gap+w2*2+gap]  = normalize(IH_s)
canvas[gap+h2+gap:gap+h2*2+gap, gap:gap+w2]               = normalize(IV_s)
canvas[gap+h2+gap:gap+h2*2+gap, gap+w2+gap:gap+w2*2+gap] = normalize(ID_s)
Image.fromarray(canvas).save('results/stego_subbands.png')

print("="*65)
print("  [TASK 1] BIEN DOI DWT ANH STEGO I'")
print("="*65)
print("  Cac dai duoc doc tu float64 .npy (chinh xac, khong mat mat)")
print("  Kich thuoc moi dai: {}x{} px".format(w2, h2))
print()
print("  NANG LUONG TUNG DAI (I' vs I goc):")
print("  {:>20} {:>16} {:>14} {:>12}".format("Dai","Stego I'","Goc I","Chenh lech"))
print("  "+"-"*64)
for nm,bs,bo in [("I'A (LL xap xi)",IA_s,LL_o),
                 ("I'H (LH ngang) ",IH_s,LH_o),
                 ("I'V (HL doc)   ",IV_s,HL_o),
                 ("I'D (HH cheo)  ",ID_s,HH_o)]:
    es=np.sum(bs**2); eo=np.sum(bo**2)
    print("  {:>20} {:>10.0f}({:.1f}%) {:>10.0f} {:>+12.0f}".format(
        nm, es, 100*es/total_s, eo, es-eo))
print()
print("  Dai co DB nhung: kem theo hang co chenh lech duong.")
print()
print("  Da luu: results/stego_subbands.png")
print("  Mo xem: eog results/stego_subbands.png")
print("="*65)
