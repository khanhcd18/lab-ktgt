import numpy as np, json

BIA_flat=np.load('results/BIA_retrieved.npy')
DB_flat =np.load('results/DB_retrieved.npy')
keys=json.load(open('keys.json'))
BLOCK_SIZE=keys['block_size']; SA_shape=keys['SA_shape']; n_BSA=keys['n_BSA']
bs=BLOCK_SIZE
BIA_list=[BIA_flat[i].reshape(bs,bs) for i in range(n_BSA)]
DB_list =[DB_flat[i].reshape(bs,bs)  for i in range(n_BSA)]

# ================================================================
# Cong thuc 2.21: BSAi = BIA'j + DB'i
# (Vi DB = BSA - BIA nen BSA = BIA + DB)
# ================================================================
def reconstruct_bsa(bia_block, db_block):
    """
    Cong thuc 2.21: BSAi = BI'Aj + DB'i
    bia_block : khoi BI'Aj tu I'A (theo K1)
    db_block  : khoi DB'i tu I'H/I'V/I'D (theo K2/K3/K4)
    """
    return bia_block.astype(float) + db_block.astype(float)
    # [CODE MAU - bo dau # de chay]
    # return bia_block.astype(float) + db_block.astype(float)

BSA_list=[reconstruct_bsa(BIA_list[i],DB_list[i]) for i in range(n_BSA)]

# Ghep lai: moi hang SA gom n_col_blocks khoi xep ngang
n_col_blocks=SA_shape[1]//bs
rows=[]
for i in range(0,n_BSA,n_col_blocks):
    if i+n_col_blocks<=n_BSA:
        rows.append(np.hstack([BSA_list[i+j] for j in range(n_col_blocks)]))
SA_recovered=np.vstack(rows)[:SA_shape[0],:SA_shape[1]]
np.save('results/SA_recovered.npy',SA_recovered)

print("="*65)
print("  [TASK 3] KHOI PHUC BSA' = BI'Aj + DB'i  (Cong thuc 2.21)")
print("="*65)
print("  SA_shape mong doi: {} | SA_recovered: {}".format(SA_shape,list(SA_recovered.shape)))
print()
print("  {:>4} {:>20} {:>20} {:>20}".format("i","BI'A[j]","DB'[i]","BSA'=BIA+DB"))
print("  "+"-"*66)
for i in range(n_BSA):
    print("  {:>4} {:>20} {:>20} {:>20}".format(
        i, str([round(v,1) for v in BIA_list[i].flatten()]),
        str([round(v,3) for v in DB_list[i].flatten()]),
        str([round(v,3) for v in BSA_list[i].flatten()])))
print()
print("  MA TRAN SA' KHOI PHUC ({}x{}):".format(*SA_recovered.shape))
for ri,row in enumerate(SA_recovered):
    vals  =[round(v,3) for v in row]
    vround=[int(round(v)) for v in row]
    chars =''.join(chr(max(0,min(127,c))) if c!=0 else '' for c in vround)
    print("  Hang {}: {} → round:{} → '{}'".format(ri,vals,vround,chars))
print()
print("  Da luu: results/SA_recovered.npy")
print("="*65)
