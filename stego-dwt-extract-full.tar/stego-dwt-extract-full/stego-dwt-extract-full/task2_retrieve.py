import numpy as np, json

IA_s=np.load('results/IA_stego.npy')
IH_s=np.load('results/IH_stego.npy')
IV_s=np.load('results/IV_stego.npy')
ID_s=np.load('results/ID_stego.npy')

keys=json.load(open('keys.json'))
K1=keys['K1']; K2=keys['K2']; K3=keys['K3']; K4=keys['K4']
BLOCK_SIZE=keys['block_size']; n_BSA=keys['n_BSA']
BIA_coords=[tuple(c) for c in keys['BIA_coords']]
BIH_coords=[tuple(c) for c in keys['BIH_coords']]
BIV_coords=[tuple(c) for c in keys['BIV_coords']]
BID_coords=[tuple(c) for c in keys['BID_coords']]

# ================================================================
# BUOC 1: Dung K1 lay BI'Aj tu I'A
# BUOC 2: Dung K2/K3/K4 lay DB'i tu I'H/I'V/I'D
# Theo giao trinh muc c) Quy trinh tach tin
# ================================================================
def get_block(matrix, r, c, bs):
    """Lay khoi bs x bs tu matrix tai (r,c)."""
    return matrix[r:r+bs, c:c+bs].copy()
    # [CODE MAU - bo dau # de chay]
    # return matrix[r:r+bs, c:c+bs].copy()

def retrieve_db(i, IH_s, IV_s, ID_s, K2, K3, K4,
                BIH_coords, BIV_coords, BID_coords, bs):
    """
    Lay DB'i tu dung dai theo khoa:
    K2[i]>=0 → tu IH  |  K3[i]>=0 → tu IV  |  K4[i]>=0 → tu ID
    """
    if K2[i]>=0:
        r,c=BIH_coords[K2[i]]; return IH_s[r:r+bs,c:c+bs].copy()
    elif K3[i]>=0:
        r,c=BIV_coords[K3[i]]; return IV_s[r:r+bs,c:c+bs].copy()
    else:
        r,c=BID_coords[K4[i]]; return ID_s[r:r+bs,c:c+bs].copy()
    # [CODE MAU - bo dau # de chay]
    # if K2[i]>=0:
    #     r,c=BIH_coords[K2[i]]; return IH_s[r:r+bs,c:c+bs].copy()
    # elif K3[i]>=0:
    #     r,c=BIV_coords[K3[i]]; return IV_s[r:r+bs,c:c+bs].copy()
    # else:
    #     r,c=BID_coords[K4[i]]; return ID_s[r:r+bs,c:c+bs].copy()

BIA_retrieved=[]; DB_retrieved=[]
for i in range(n_BSA):
    r,c=BIA_coords[K1[i]]
    BIA_retrieved.append(get_block(IA_s,r,c,BLOCK_SIZE))
    DB_retrieved.append(retrieve_db(i,IH_s,IV_s,ID_s,K2,K3,K4,
                                    BIH_coords,BIV_coords,BID_coords,BLOCK_SIZE))

np.save('results/BIA_retrieved.npy',np.array([b.flatten() for b in BIA_retrieved]))
np.save('results/DB_retrieved.npy', np.array([b.flatten() for b in DB_retrieved]))

print("="*62)
print("  [TASK 2] LAY KHOI THEO KHOA K1, K2, K3, K4")
print("="*62)
print("  K1={} | K2 dung IH:{} | K3 dung IV:{} | K4 dung ID:{}".format(
    K1, sum(1 for k in K2 if k>=0), sum(1 for k in K3 if k>=0), sum(1 for k in K4 if k>=0)))
print()
print("  BUOC 1 - BI'Aj tu I'A (theo K1):")
for i in range(n_BSA):
    print("    BI'A[{}] = {} (j={})".format(i,BIA_retrieved[i].flatten().tolist(),K1[i]))
print()
print("  BUOC 2 - DB'i tu I'H/I'V/I'D (theo K2/K3/K4):")
for i in range(n_BSA):
    src='IH(k={})'.format(K2[i]) if K2[i]>=0 else 'IV(l={})'.format(K3[i]) if K3[i]>=0 else 'ID(p={})'.format(K4[i])
    print("    DB'[{}] = {} (tu {})".format(i,[round(v,3) for v in DB_retrieved[i].flatten()],src))
print()
print("  Da luu: BIA_retrieved.npy, DB_retrieved.npy")
print("="*62)
